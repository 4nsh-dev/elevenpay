# ElevenPay — Project Status

_Last updated: 7 July 2026 — persistent transaction storage implemented._

## Snapshot

| Layer | Status |
| --- | --- |
| UI / design system / navigation | ✅ Built (untouched) |
| Authentication (Supabase Auth) | ✅ Built |
| Auth ↔ Supabase profiles wiring | ✅ Done |
| WDK wallet layer (custody, signing) | ✅ Built (untouched) |
| WDK ↔ Supabase wallet sync | ✅ Done |
| **Persistent transaction storage** | ✅ **Done — this pass** |
| Database schema (10 tables, FKs, indexes) | ✅ Done |
| Row Level Security (default-deny) | ✅ Done (+ client status recording policy) |
| Triggers (guards, profile bootstrap, settlement) | ✅ Done |
| Views (privacy shaping) | ✅ Done |
| RPCs (atomic money operations) | ✅ Done |
| Database types (`src/types/database.ts`) | ✅ Done |
| Seed data | ✅ Done |
| Repository/data-access layer | ✅ Done |
| Edge functions (submit-tx SUCCESS confirmation, resolve-pool, faucet) | ⏳ Next |
| Wiring feature screens to the ledger (replace mock data) | ⏳ Next |
| Realtime subscriptions | ⏳ Next |

## This pass: persistent transaction storage

The durable ledger is `public.transactions` in Supabase; the device
SecureStore history remains a local cache. New persistence layer in
`src/features/payments/transaction-storage.ts`:

- **Outgoing transactions saved** — a PENDING intent row (idempotency-keyed)
  is persisted before signing; `recordAndBroadcast()` wraps the whole
  pipeline: save PENDING → WDK sign & broadcast → record status.
- **Incoming transactions saved** — received sends, faucet drips, and pool
  rewards are written server-side (clients cannot forge incoming rows);
  `loadLedger()` pulls both directions into the new transactions store.
- **Transaction status** — full lifecycle persisted: PENDING → BROADCAST →
  SUCCESS/FAILED. New migration `20260707000800` lets the sender record
  BROADCAST/FAILED on their own PENDING intents; SUCCESS stays service-role
  only (guard trigger + RLS unchanged elsewhere).
- **Transaction hashes** — the on-chain hash is stored on the row at
  broadcast time (required by the policy for the BROADCAST flip).
- **Retry support** — writes that fail on connectivity go into an
  AsyncStorage outbox and replay in order on the next ledger load / app
  start; idempotency keys make replayed creates double-pay-proof. Failed
  payments can be retried safely (old intent marked FAILED, fresh intent
  created).
- **Loading states / error handling** — `isLedgerLoading`, `ledgerError`,
  and `outboxCount` on the new `useTransactionsStore`; friendly messages;
  ledger loads never throw into the UI.
- **UI unchanged** — ledger entries are shaped as the existing
  `ActivityItem` view model, so screens can adopt them without rework. No
  screen/component files touched.

### Files changed in this pass

```
supabase/migrations/20260707000800_transactions_client_updates.sql  (new — sender records BROADCAST/FAILED)
src/stores/transactions.ts                    (new — ledger + loading/error/outbox state)
src/features/payments/transaction-storage.ts  (new — persistence service + outbox + pipeline)
src/features/payments/index.ts                (modified — exports the storage layer)
src/features/wallet/wallet-service.ts         (modified — loads ledger on hydrate, clears on sign-out)
supabase/README.md                            (updated — migration list + security model)
PROJECT_STATUS.md                             (updated)
```

Not modified: `src/services/wdk/**`, all UI components and screens, auth
files, other stores.

## Previous passes

- **WDK ↔ Supabase wallet sync** — wallet registration, balance cache, and
  metadata sync; no key material leaves the device. See
  `docs/wallet-supabase-sync.md`.
- **Auth ↔ profiles** — profile auto-created at signup by the
  `on_auth_user_created` trigger; fetched with retry on every auth event
  (loading + error state in the session store); wallet linked to profile.
- **Supabase backend foundation** — seven migrations (all 10 tables from
  `DATABASE.md`, FKs, 17 indexes, guard/bootstrap triggers, privacy views,
  default-deny RLS, atomic RPCs), seed data, `config.toml`, full
  `src/types/database.ts`, typed repository layer under
  `src/services/supabase/repositories/`. See `supabase/README.md`.

## How to apply

```bash
npx supabase start && npx supabase db reset   # local (applies new 0800 migration)
# or
npx supabase link --project-ref <ref> && npx supabase db push   # hosted
```
