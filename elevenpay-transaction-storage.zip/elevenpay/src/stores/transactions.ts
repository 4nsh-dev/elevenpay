import { create } from 'zustand';

import type { ActivityItem } from '@/types/activity';

/**
 * Persistent ledger state — rows from `public.transactions` in Supabase
 * (incoming + outgoing), shaped as the UI's existing ActivityItem view model.
 * Additive: the device-history store in stores/wallet.ts is untouched.
 */
export type LedgerEntry = ActivityItem & {
  referenceId: string | null;
  idempotencyKey: string | null;
};

interface TransactionsState {
  ledger: LedgerEntry[];
  isLedgerLoading: boolean;
  ledgerError: string | null;
  /** Writes waiting in the offline outbox (0 = fully synced). */
  outboxCount: number;
  setLedger: (ledger: LedgerEntry[]) => void;
  setLedgerLoading: (isLedgerLoading: boolean) => void;
  setLedgerError: (ledgerError: string | null) => void;
  setOutboxCount: (outboxCount: number) => void;
  clearLedger: () => void;
}

export const useTransactionsStore = create<TransactionsState>((set) => ({
  ledger: [],
  isLedgerLoading: false,
  ledgerError: null,
  outboxCount: 0,
  setLedger: (ledger) => set({ ledger, isLedgerLoading: false, ledgerError: null }),
  setLedgerLoading: (isLedgerLoading) => set({ isLedgerLoading }),
  setLedgerError: (ledgerError) => set({ ledgerError, isLedgerLoading: false }),
  setOutboxCount: (outboxCount) => set({ outboxCount }),
  clearLedger: () =>
    set({ ledger: [], isLedgerLoading: false, ledgerError: null, outboxCount: 0 }),
}));
