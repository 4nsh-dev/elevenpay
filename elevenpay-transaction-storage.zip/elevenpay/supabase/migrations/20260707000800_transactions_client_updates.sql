-- ============================================================================
-- 0800: Client status recording for the payment pipeline
--
-- The app signs and broadcasts with WDK on-device, so the client must be able
-- to record the broadcast hash on its own PENDING intent (or mark it FAILED
-- when signing/broadcast fails). This policy opens exactly that hole:
--
--   PENDING -> BROADCAST (transaction_hash required)  — sender only
--   PENDING -> FAILED                                  — sender only
--
-- SUCCESS remains service-role only (on-chain verification by the submit-tx
-- edge function). The transactions_guard trigger still enforces column
-- immutability and legal transitions on top of this policy.
-- ============================================================================

create policy transactions_update_own_pending
  on public.transactions for update to authenticated
  using (
    status = 'PENDING'
    and exists (
      select 1 from public.wallets w
      where w.id = transactions.sender_wallet
        and w.user_id = (select auth.uid())
    )
  )
  with check (
    status in ('BROADCAST', 'FAILED')
    and (status <> 'BROADCAST' or transaction_hash is not null)
    and confirmed_at is null
    and exists (
      select 1 from public.wallets w
      where w.id = sender_wallet
        and w.user_id = (select auth.uid())
    )
  );

comment on policy transactions_update_own_pending on public.transactions is
  'Senders may record BROADCAST (with hash) or FAILED on their own PENDING intents. SUCCESS stays service-role only.';
