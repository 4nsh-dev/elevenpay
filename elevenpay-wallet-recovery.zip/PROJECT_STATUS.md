# ElevenPay — Project Status

_Last updated: 8 July 2026 — Wallet recovery shipped (reveal, verify, remind; device-only)._

## Snapshot

| Area | Status |
| --- | --- |
| Supabase foundation (schema, RLS, RPCs, types, seeds, repositories) | ✅ Done |
| Auth ↔ profiles | ✅ Done |
| WDK wallet ↔ Supabase sync (addresses + balances, never keys) | ✅ Done |
| Persistent transaction storage (ledger + outbox) | ✅ Done |
| Watch parties (live data, join, payments) | ✅ Done |
| Prediction pools (create, join, simulate, payouts) | ✅ Done |
| Split bills (create, AI shares, requests, WDK payments, history) | ✅ Done |
| AI Copilot (explain, summarize, prepare drafts, recommend) | ✅ Done |
| **Wallet recovery (reveal, verify, backup reminder)** | ✅ **Done — this pass** |
| Edge functions for on-chain verification | ⏳ Next |
| Realtime subscriptions | ⏳ Next |
| Guest share-link claim flow | ⏳ Next |

## This pass: Wallet recovery

- **Reveal phrase** — new `/recovery` screen: two explicit risk acknowledgments, then the 12 words as numbered chips with a 60-second auto-hide.
- **Verify phrase** — 3-question positional quiz ("Word #4?") graded locally; passing marks the wallet backed up.
- **Backup reminder** — Wallet-tab banner until verified (snoozable for 24h) plus a Profile security row showing backup status; survives restarts.
- **Secure confirmation** — the mnemonic read goes through SecureStore `requireAuthentication`, so the OS biometric/passcode prompt gates every reveal. No new dependencies.
- **No database storage** — the phrase and the backup flag live only in `expo-secure-store` (`WHEN_UNLOCKED_THIS_DEVICE_ONLY`); Supabase is never touched by this feature.
- **WDK best practices** — reuses `wdkService.revealRecoveryPhrase`; words are transient state (auto-hide, wiped on unmount), never logged, never clipboard-copied; restore stays on the existing create-or-restore screen.

### Files changed in this pass

```
src/features/recovery/backup-status.ts   (new)
src/features/recovery/use-recovery.ts    (new)
src/features/recovery/index.ts           (new)
app/recovery.tsx                         (new)
app/(tabs)/wallet.tsx                    (modified — backup reminder banner)
app/(tabs)/profile.tsx                   (modified — recovery phrase row)
docs/wallet-recovery.md                  (new)
PROJECT_STATUS.md                        (updated)
```

## Previous passes

- Supabase foundation — migrations, RLS, database types, seeds, repositories.
- Auth ↔ profiles — signup creates a profile, login hydrates it.
- Wallet sync — WDK addresses/balances registered in Supabase (docs/wallet-supabase-sync.md).
- Persistent transactions — PENDING -> BROADCAST ledger with offline outbox.
- Watch parties — live discovery, atomic joins, verified payments (docs/watch-party-supabase.md).
- Prediction pools — pools, entries, simulation, WDK payouts (docs/prediction-pools-supabase.md).
- Split bills — create, AI shares, requests, WDK payments, history (docs/split-bill-supabase.md).
- AI Copilot — structured function calling, key-free drafts (docs/ai-copilot.md).

## How to apply

- **No new migrations and no new dependencies in this pass** — recovery is app-layer and device-only.
- Local: `npx supabase start` then `npx supabase db reset` (unchanged since the split-bill pass).
- Hosted: `npx supabase link` then `npx supabase db push`.
