/**
 * Prediction pool feature — live Supabase pools, creation, entries, result
 * simulation, and WDK-signed payout proof. (Dummy PREDICTION_POOLS retired.)
 */
export {
  beginEnterPool,
  buildPoolRewardDraft,
  countdownLabel,
  createPool,
  formatPoolDate,
  friendlyPoolError,
  getPoolDetail,
  getTeam,
  listPools,
  poolEntryTransaction,
  poolRewardTransaction,
  simulatePool,
  type CreatePoolInput,
  type PoolDetailData,
  type PoolTeam,
  type PredictionPoolView,
  type SimulatePoolOutcome,
} from './prediction-pool-service';
export { usePoolDetail, usePredictionPools } from './use-prediction-pools';
