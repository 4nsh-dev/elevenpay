/**
 * DEPRECATED — dummy prediction pool data removed.
 *
 * Pools now come from Supabase via `prediction-pool-service.ts` (see
 * `docs/prediction-pools-supabase.md`). This file is kept only because the
 * update is delivered as a zip overlay, which cannot delete files. It is safe
 * to delete this file from the repository.
 */
export {};
