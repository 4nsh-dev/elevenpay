/**
 * React hooks for live prediction pool data with loading and error states.
 */

import { useCallback, useEffect, useState } from 'react';

import {
  getPoolDetail,
  listPools,
  type PoolDetailData,
  type PredictionPoolView,
} from './prediction-pool-service';

export function usePredictionPools() {
  const [pools, setPools] = useState<PredictionPoolView[]>([]);
  const [joinedPoolIds, setJoinedPoolIds] = useState<Set<string>>(new Set());
  const [isLoading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    try {
      setError(null);
      const result = await listPools();
      setPools(result.pools);
      setJoinedPoolIds(result.joinedPoolIds);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Could not load prediction pools.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  return { pools, joinedPoolIds, isLoading, error, reload };
}

export function usePoolDetail(id: string | undefined) {
  const [detail, setDetail] = useState<PoolDetailData | null>(null);
  const [isLoading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    if (!id) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    try {
      setError(null);
      const result = await getPoolDetail(id);
      setDetail(result);
      setNotFound(result === null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Could not load this pool.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void reload();
  }, [reload]);

  return { detail, isLoading, notFound, error, reload };
}
