# Prediction pools on Supabase

How the prediction pool feature works after the live-data pass. The dummy
`PREDICTION_POOLS` module is retired — `prediction-pool-data.ts` is now an
empty stub (zip overlays cannot delete files; it is safe to delete it from
the repository).

## Data model

- `prediction_pools` — one row per pool (`match_name`, `team_a`/`team_b`,
  `entry_fee`, denormalized `prize_pool`, `status`, `winner_team`,
  `closes_at`). Readable by any signed-in user.
- `predictions` — one row per pick, `unique (pool_id, user_id)`. RLS: your
  own pick is always visible; other users' picks only after the pool closes
  (no copying picks). Picks are final — client updates are blocked by trigger
  guards; only the server can set `is_winner`.
- `transactions` — `POOL_ENTRY` (entry fee to treasury) and `POOL_REWARD`
  (treasury to winner) ledger rows.
- Treasury — the seeded `elevenpay_treasury` user's wallet is the escrow
  stand-in (`treasury_wallet()`); its address is resolved client-side via the
  `resolve_wallet` RPC.

## Flows

### Pool creation

`createPool()` (feature service → pools repository) → **`create_pool` RPC**
(migration `20260707001000`): requires auth, validates match name, distinct
teams, positive entry fee, and a future close time, then inserts an `OPEN`
pool. There is no dedicated creation screen in the current UI, so this is
exposed at the service/repository layer; seeded pools and service-created
pools flow through the same read path.

### Join pool + entry payment

1. Pick a team on the pool screen → `beginEnterPool()` → **`enter_pool` RPC**
   stores the prediction atomically (server clock, one final pick per user,
   `POOL_CLOSED`/`ALREADY_EXISTS` guards) and accrues the denormalized prize
   pool.
2. The RPC returns a payment template. The client builds a `PaymentDraft` to
   the treasury address and hands it to the existing confirm sheet, which
   runs the persistent ledger pipeline (`recordAndBroadcast`: PENDING ledger
   row → WDK sign → BROADCAST + hash, idempotency-keyed with outbox retry).
   `metadata.receiverWalletId` links the ledger row to the treasury wallet.

### Store prediction

Predictions live in the `predictions` table from the moment `enter_pool`
succeeds. The screen treats the server row as the source of truth for the
locked pick (`selected_team`), and `is_winner` after resolution.

### Simulate result

`simulatePool()` → **`simulate_pool_result` RPC** (new): requires the caller
to have entered the pool, then invokes the service-role `resolve_pool`
internally (the SECURITY DEFINER wrapper runs as the function owner, so the
`is_service_role()` guard passes). `resolve_pool` picks a random winner,
marks `is_winner` on every prediction, finishes the linked match, and
computes `payout = prize / winner count` from the predictions table.

### Automatic winnings distribution

- **Server (atomic with resolution):** `resolve_pool` mints a `POOL_REWARD`
  ledger row from the treasury wallet to each winner's wallet and credits
  each winner's balance.
- **Client (WDK):** the winning device records a WDK-signed payout proof for
  the same amount (`wdkService.recordDemoReward`) so the reward also appears
  in on-device WDK history — the same flow the original demo used, now with
  server-settled amounts. Losing devices simply see the result.

## Entries count while a pool is open

Individual picks are hidden by RLS until the pool closes, so the visible
entry count is derived from the accrued prize pool
(`prize_pool / entry_fee`).

## Error handling

RPC errors use stable prefixes (`ALREADY_EXISTS`, `POOL_CLOSED`,
`UNAUTHENTICATED`, `NOT_FOUND`, `CONFLICT`, `VALIDATION_ERROR`) mapped to
friendly copy by `friendlyPoolError()`. Both screens have loading, error +
retry, and empty states.

## Hardening notes (production)

- Revoke `simulate_pool_result` and resolve pools exclusively via the
  `resolve-pool` edge function with real match results — the RPC exists for
  the demo only.
- Verify the `POOL_ENTRY` ledger row (like watch parties'
  `confirm_party_payment`) before counting an entry as paid; today the pick
  is stored at RPC time and payment follows the standard pipeline.
- Real on-chain payouts require a treasury signer (edge function or
  custodial service); the WDK proof is a device-local mirror, not a treasury
  signature.
