-- ============================================================================
-- Prediction pools: client pool creation + demo result simulation
--
-- create_pool          — any signed-in user can open a pool (validated).
-- simulate_pool_result — demo-only client trigger that wraps the service-role
--                        resolve_pool (SECURITY DEFINER runs as the function
--                        owner, so the is_service_role() guard passes inside).
--
-- Hardening note: in production, revoke simulate_pool_result and resolve pools
-- exclusively via the resolve-pool edge function with real match results.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- create_pool — validated pool creation
-- ----------------------------------------------------------------------------
create or replace function public.create_pool(
  p_match_name text,
  p_team_a text,
  p_team_b text,
  p_entry_fee numeric,
  p_closes_at timestamptz,
  p_match_id uuid default null,
  p_watch_party_id uuid default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_pool_id uuid;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to create a pool';
  end if;
  if coalesce(trim(p_match_name), '') = '' then
    raise exception 'VALIDATION_ERROR: match_name is required';
  end if;
  if coalesce(trim(p_team_a), '') = '' or coalesce(trim(p_team_b), '') = '' then
    raise exception 'VALIDATION_ERROR: both team names are required';
  end if;
  if lower(trim(p_team_a)) = lower(trim(p_team_b)) then
    raise exception 'VALIDATION_ERROR: teams must be different';
  end if;
  if p_entry_fee is null or p_entry_fee <= 0 then
    raise exception 'VALIDATION_ERROR: entry_fee must be positive';
  end if;
  if p_closes_at is null or p_closes_at <= now() then
    raise exception 'VALIDATION_ERROR: closes_at must be in the future';
  end if;
  if p_match_id is not null
    and not exists (select 1 from public.matches m where m.id = p_match_id) then
    raise exception 'NOT_FOUND: match does not exist';
  end if;
  if p_watch_party_id is not null
    and not exists (select 1 from public.watch_parties wp where wp.id = p_watch_party_id) then
    raise exception 'NOT_FOUND: watch party does not exist';
  end if;

  insert into public.prediction_pools (
    match_id, watch_party_id, match_name, team_a, team_b, entry_fee, status, closes_at
  )
  values (
    p_match_id, p_watch_party_id, trim(p_match_name), trim(p_team_a), trim(p_team_b),
    p_entry_fee, 'OPEN', p_closes_at
  )
  returning id into v_pool_id;

  return jsonb_build_object(
    'pool_id', v_pool_id,
    'status', 'OPEN',
    'closes_at', p_closes_at
  );
end;
$$;

revoke all on function public.create_pool(text, text, text, numeric, timestamptz, uuid, uuid) from public;
grant execute on function public.create_pool(text, text, text, numeric, timestamptz, uuid, uuid) to authenticated;

-- ----------------------------------------------------------------------------
-- simulate_pool_result — demo resolution trigger for pool participants
-- ----------------------------------------------------------------------------
create or replace function public.simulate_pool_result(p_pool_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_my public.predictions%rowtype;
  v_result jsonb;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to simulate a result';
  end if;

  select * into v_my from public.predictions
  where pool_id = p_pool_id and user_id = v_uid;
  if not found then
    raise exception 'NOT_FOUND: enter the pool before simulating its result';
  end if;

  -- resolve_pool checks is_service_role(); this SECURITY DEFINER wrapper runs
  -- as the function owner, so the guard passes. resolve_pool picks a random
  -- winner, marks predictions, mints POOL_REWARD ledger rows from the
  -- treasury, credits winner balances, and finishes the match + pool.
  v_result := public.resolve_pool(p_pool_id, null, true);

  select * into v_my from public.predictions
  where pool_id = p_pool_id and user_id = v_uid;

  return v_result || jsonb_build_object(
    'my_pick', v_my.selected_team,
    'did_win', coalesce(v_my.is_winner, false)
  );
end;
$$;

revoke all on function public.simulate_pool_result(uuid) from public;
grant execute on function public.simulate_pool_result(uuid) to authenticated;
