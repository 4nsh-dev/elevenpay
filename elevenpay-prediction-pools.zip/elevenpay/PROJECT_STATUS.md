# ElevenPay — Project Status

_Last updated: 8 July 2026 — prediction pools wired to Supabase (dummy data removed)._

## Snapshot

| Layer | Status |
| --- | --- |
| UI / design system / navigation | ✅ Built (untouched) |
| Authentication (Supabase Auth) | ✅ Built |
| Auth ↔ Supabase profiles wiring | ✅ Done |
| WDK wallet layer (custody, signing) | ✅ Built (untouched) |
| WDK ↔ Supabase wallet sync | ✅ Done |
| Persistent transaction storage | ✅ Done |
| Watch parties (live data, joins, participants, payments) | ✅ Done |
| **Prediction pools (creation, entries, payments, results, payouts)** | ✅ **Done — this pass** |
| Database schema (10 tables, FKs, indexes) | ✅ Done |
| Row Level Security (default-deny) | ✅ Done |
| Triggers (guards, profile bootstrap, settlement) | ✅ Done |
| Views (privacy shaping) | ✅ Done |
| RPCs (atomic money operations) | ✅ Done (+ `create_pool`, `simulate_pool_result`) |
| Database types (`src/types/database.ts`) | ✅ Done |
| Seed data | ✅ Done |
| Repository/data-access layer | ✅ Done |
| Splits wired to live data | ⏳ Next |
| Edge functions (submit-tx SUCCESS confirmation, faucet) | ⏳ Next |
| Realtime subscriptions | ⏳ Next |

## This pass: prediction pools on live data

Every dummy prediction pool is gone. The Watch tab pools section and the
pool detail screen now run on Supabase (full write-up in
`docs/prediction-pools-supabase.md`):

- **Pool creation** — new `create_pool` RPC (authenticated + validated) with
  `createPool()` exposed at the service and repository layers. No dedicated
  screen in the current UI; seeded and created pools share one read path.
- **Join pool** — the atomic `enter_pool` RPC stores the pick server-side
  (one final pick per user, server-clock close enforcement, stable error
  prefixes mapped to friendly copy).
- **Entry payment** — the entry fee runs through the persistent ledger
  pipeline (`recordAndBroadcast`: PENDING → WDK sign → BROADCAST + hash) to
  the treasury wallet, linked via `metadata.receiverWalletId`.
- **Store prediction** — `predictions` rows with RLS (own pick always;
  others' picks only after close) and finality trigger guards.
- **Simulate result** — new `simulate_pool_result` RPC wraps the
  service-role `resolve_pool`: random winner, `is_winner` marking, match +
  pool finished atomically.
- **Automatic winnings distribution** — `resolve_pool` mints `POOL_REWARD`
  ledger rows from the treasury and credits winner balances in the same
  transaction; the winning client then records a WDK-signed payout proof
  mirroring the ledger payout.
- **UI preserved** — both screens diffed against the originals; layout and
  components unchanged, with loading/error/empty states added.

### Files changed in this pass

```
supabase/migrations/20260707001000_pool_creation_and_simulation.sql  (new)
src/features/prediction-pool/prediction-pool-service.ts              (new)
src/features/prediction-pool/use-prediction-pools.ts                 (new)
src/features/prediction-pool/prediction-pool-data.ts                 (gutted stub — safe to delete)
src/features/prediction-pool/index.ts                                (rewritten)
src/services/supabase/repositories/predictionPools.ts                (modified — createPool, simulatePoolResult)
src/types/database.ts                                                (modified — RPC typings)
app/(tabs)/watch.tsx                                                 (modified — pools section on live data)
app/pool/[id].tsx                                                    (rewritten — live data, same layout)
docs/prediction-pools-supabase.md                                    (new)
PROJECT_STATUS.md                                                    (this file)
```

## Previous passes

- **Supabase foundation** — schema, RLS, triggers, views, RPCs, types, seed
  data, repositories (`supabase/README.md`).
- **Auth ↔ profiles** — automatic profile bootstrap after signup, profile
  fetch on login, session store wiring.
- **WDK ↔ wallet sync** — wallet registration + balance/metadata sync
  (`docs/wallet-supabase-sync.md`). Private keys never leave the device.
- **Persistent transaction storage** — idempotency-keyed ledger writes with
  an AsyncStorage outbox and retry (`supabase/README.md`).
- **Watch parties** — live parties, atomic joins, participants, capacity,
  payment-backed seats (`docs/watch-party-supabase.md`).

## How to apply

Local: `npx supabase start && npx supabase db reset` (applies all migrations
+ seed). Hosted: `npx supabase link --project-ref <ref> && npx supabase db
push`.
