import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  CalendarClock,
  CheckCircle2,
  CircleDollarSign,
  ShieldCheck,
  Trophy,
  Users,
  type LucideIcon,
} from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, Text, View } from 'react-native';

import { GlassCard, PrimaryButton, Screen, SecondaryButton, StatusChip } from '@/components/ui';
import { ProtectedRoute } from '@/features/auth';
import {
  beginEnterPool,
  buildPoolRewardDraft,
  countdownLabel,
  formatPoolDate,
  friendlyPoolError,
  getTeam,
  poolRewardTransaction,
  simulatePool,
  usePoolDetail,
} from '@/features/prediction-pool';
import { refreshTransactionHistory } from '@/features/wallet';
import { formatUsdt, shortenAddress } from '@/lib/format';
import { wdkService } from '@/services/wdk';
import { useSessionStore } from '@/stores/session';
import { useUiStore } from '@/stores/ui';
import { useWalletStore } from '@/stores/wallet';
import { colors, iconSize } from '@/theme/tokens';

import type { PoolTeam } from '@/features/prediction-pool';

function InfoTile({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
}) {
  return (
    <View className="flex-1 rounded-input bg-surface-slate p-4">
      <View className="flex-row items-center gap-2">
        <Icon size={iconSize.inline} color={colors.brand.primary} />
        <Text className="font-inter-medium text-[11px] uppercase tracking-widest text-content-tertiary">
          {label}
        </Text>
      </View>
      <Text className="mt-2 font-inter-semibold text-[17px] text-content-primary">{value}</Text>
    </View>
  );
}

function PickButton({
  team,
  selected,
  locked,
  onPress,
}: {
  team: PoolTeam;
  selected: boolean;
  locked: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected, disabled: locked }}
      onPress={locked ? undefined : onPress}
      className={`flex-1 rounded-input border p-4 active:scale-[0.98] ${
        selected ? 'border-brand-primary bg-brand-primary/10' : 'border-white/10 bg-surface-slate'
      }`}
    >
      <Text className="font-inter-medium text-[11px] uppercase tracking-widest text-content-tertiary">
        Pick
      </Text>
      <Text className="mt-2 font-inter-semibold text-[18px] text-content-primary">{team.name}</Text>
      <Text className="mt-1 font-inter text-[13px] text-content-secondary">{team.shortName}</Text>
    </Pressable>
  );
}

/** Pool detail -> choose winner -> entry payment -> simulated result -> treasury payout + WDK proof. */
export default function PoolDetail() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { detail, isLoading, notFound, error, reload } = usePoolDetail(id);
  const userId = useSessionStore((s) => s.userId);
  const setPendingDraft = useUiStore((s) => s.setPendingDraft);
  const transactions = useWalletStore((s) => s.transactions);
  const walletAddress = useWalletStore((s) => s.address);
  const [selectedPick, setSelectedPick] = useState<string | null>(null);
  const [now, setNow] = useState(new Date());
  const [isJoining, setJoining] = useState(false);
  const [joinError, setJoinError] = useState<string | null>(null);
  const [isDistributing, setDistributing] = useState(false);
  const [simulationError, setSimulationError] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(timer);
  }, []);

  if (isLoading) {
    return (
      <ProtectedRoute>
        <Screen>
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator color={colors.brand.primary} />
          </View>
        </Screen>
      </ProtectedRoute>
    );
  }

  if (notFound || error || !detail) {
    return (
      <ProtectedRoute>
        <Screen>
          <View className="flex-1 justify-center gap-4">
            <Text className="font-inter-semibold text-2xl text-content-primary">
              {error ? 'Something went wrong' : 'Pool not found'}
            </Text>
            <Text className="font-inter text-[15px] leading-6 text-content-secondary">
              {error ?? 'This prediction pool is no longer available.'}
            </Text>
            {error ? <SecondaryButton label="Try again" onPress={() => void reload()} /> : null}
            <SecondaryButton label="Back to events" onPress={() => router.back()} />
          </View>
        </Screen>
      </ProtectedRoute>
    );
  }

  const { pool, myPrediction } = detail;
  const currentPool = pool;
  const reward = poolRewardTransaction(transactions, currentPool.id);
  const lockedPick = myPrediction?.selected_team ?? null;
  const activePick = lockedPick ?? selectedPick;
  const pickedTeam = getTeam(currentPool, activePick);
  const visibleWinner = getTeam(currentPool, currentPool.winnerTeam);
  const isJoined = Boolean(myPrediction);
  const players = currentPool.entries;
  const prizePool = currentPool.prizePool;
  const isResolved = currentPool.status === 'FINISHED';
  const isClosed =
    currentPool.status !== 'OPEN' || countdownLabel(currentPool.closesAt, now) === 'Closed';
  const canJoin = Boolean(walletAddress && pickedTeam && !isJoined && !isClosed && !isJoining);
  const userWon = myPrediction?.is_winner === true;

  async function joinPool() {
    if (!pickedTeam || !canJoin) return;
    setJoinError(null);
    setJoining(true);
    try {
      const draft = await beginEnterPool(currentPool, pickedTeam);
      setPendingDraft(draft);
      router.push('/confirm');
      await reload();
    } catch (caught) {
      setJoinError(friendlyPoolError(caught));
      await reload();
    } finally {
      setJoining(false);
    }
  }

  async function simulateMatch() {
    if (!isJoined || !lockedPick || reward || isResolved || isDistributing) return;

    setSimulationError(null);
    setDistributing(true);
    try {
      const result = await simulatePool(currentPool.id);
      const winnerTeam = getTeam(currentPool, result.winnerTeam);

      if (result.didWin && winnerTeam) {
        await wdkService.recordDemoReward(
          buildPoolRewardDraft(currentPool, winnerTeam, result.payoutPerWinner),
          userId,
        );
        await refreshTransactionHistory(userId);
      }
      await reload();
    } catch (caught) {
      setSimulationError(friendlyPoolError(caught));
      await reload();
    } finally {
      setDistributing(false);
    }
  }

  return (
    <ProtectedRoute>
      <Screen>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerClassName="gap-6 py-4">
          <View className="gap-2">
            <Text className="font-inter-medium text-[11px] uppercase tracking-widest text-brand-primary">
              Prediction Pool
            </Text>
            <Text className="font-inter-bold text-3xl text-content-primary">{pool.match}</Text>
            <Text className="font-inter text-[15px] leading-6 text-content-secondary">
              Choose winner, pay entry fee, simulate result. Reward demo uses WDK signed proof.
            </Text>
          </View>

          <GlassCard>
            <View className="gap-4">
              <View className="flex-row items-start justify-between gap-4">
                <View className="flex-1">
                  <Text className="font-inter-semibold text-[20px] text-content-primary">
                    {pool.competition}
                  </Text>
                  <Text className="mt-1 font-inter text-[13px] text-content-secondary">
                    Closes in {countdownLabel(pool.closesAt, now)}
                  </Text>
                </View>
                <StatusChip status={reward ? 'PAID' : isJoined ? 'PENDING' : 'OPEN'} />
              </View>

              <View className="flex-row gap-3">
                <InfoTile
                  icon={CircleDollarSign}
                  label="Prize Pool"
                  value={`${formatUsdt(prizePool)} USDT`}
                />
                <InfoTile icon={Trophy} label="Entry" value={`${formatUsdt(pool.entryFee)} USDT`} />
              </View>

              <View className="flex-row gap-3">
                <InfoTile icon={Users} label="Entries" value={`${players}`} />
                <InfoTile
                  icon={CalendarClock}
                  label="Kickoff"
                  value={formatPoolDate(pool.kickoffAt)}
                />
              </View>

              <View className="rounded-input bg-surface-slate p-4">
                <Text className="font-inter-medium text-[11px] uppercase tracking-widest text-content-tertiary">
                  Pool Wallet
                </Text>
                <Text className="mt-2 font-inter-semibold text-[15px] text-content-primary">
                  {pool.poolWallet ? shortenAddress(pool.poolWallet, 8) : 'Not linked yet'}
                </Text>
              </View>
            </View>
          </GlassCard>

          <GlassCard>
            <View className="gap-4">
              <View>
                <Text className="font-inter-semibold text-[18px] text-content-primary">
                  Choose winner
                </Text>
                <Text className="mt-1 font-inter text-[13px] leading-5 text-content-secondary">
                  Pick locks when you join. Picks are final.
                </Text>
              </View>

              <View className="flex-row gap-3">
                {pool.teams.map((team) => (
                  <PickButton
                    key={team.id}
                    team={team}
                    selected={activePick === team.id}
                    locked={isJoined}
                    onPress={() => setSelectedPick(team.id)}
                  />
                ))}
              </View>

              {isJoined && pickedTeam ? (
                <View className="flex-row items-center gap-3 rounded-input border border-brand-primary/20 bg-brand-primary/10 p-4">
                  <CheckCircle2 size={iconSize.row} color={colors.brand.primary} />
                  <Text className="flex-1 font-inter text-[13px] leading-5 text-content-secondary">
                    Pick locked in Supabase: {pickedTeam.name}.
                  </Text>
                </View>
              ) : null}

              {joinError ? (
                <View className="rounded-input border border-state-error/30 bg-state-error/10 p-3">
                  <Text className="font-inter text-[13px] leading-5 text-state-error">
                    {joinError}
                  </Text>
                </View>
              ) : null}

              <PrimaryButton
                label={isJoined ? 'Entry confirmed' : 'Join pool'}
                disabled={!canJoin}
                loading={isJoining}
                onPress={joinPool}
              />
            </View>
          </GlassCard>

          <GlassCard>
            <View className="gap-4">
              <View>
                <Text className="font-inter-semibold text-[18px] text-content-primary">
                  Simulate match
                </Text>
                <Text className="mt-1 font-inter text-[13px] leading-5 text-content-secondary">
                  Demo result resolves in Supabase. Winner payouts are credited from the treasury
                  and mirrored with a WDK signed proof.
                </Text>
              </View>

              {visibleWinner ? (
                <View className="rounded-input bg-surface-slate p-4">
                  <Text className="font-inter-medium text-[11px] uppercase tracking-widest text-content-tertiary">
                    Result
                  </Text>
                  <Text className="mt-2 font-inter-semibold text-[18px] text-content-primary">
                    {visibleWinner.name} wins
                  </Text>
                  <Text className="mt-2 font-inter text-[13px] leading-5 text-content-secondary">
                    {userWon
                      ? reward
                        ? `Reward proof recorded: ${formatUsdt(reward.amount)} USDT`
                        : 'You won. Winnings credited from the treasury.'
                      : 'Your pick did not win this simulation.'}
                  </Text>
                </View>
              ) : null}

              {isDistributing ? (
                <View className="flex-row items-center gap-3 rounded-input border border-brand-primary/20 bg-brand-primary/10 p-3">
                  <ActivityIndicator color={colors.brand.primary} />
                  <Text className="flex-1 font-inter text-[13px] leading-5 text-content-secondary">
                    WDK signing demo reward distribution...
                  </Text>
                </View>
              ) : null}

              {simulationError ? (
                <View className="rounded-input border border-state-error/30 bg-state-error/10 p-3">
                  <Text className="font-inter text-[13px] leading-5 text-state-error">
                    {simulationError}
                  </Text>
                </View>
              ) : null}

              <View className="flex-row gap-3 rounded-input border border-white/10 bg-surface-slate p-4">
                <ShieldCheck size={iconSize.row} color={colors.brand.primary} />
                <Text className="flex-1 font-inter text-[13px] leading-5 text-content-secondary">
                  Payouts settle in the Supabase treasury ledger and are mirrored as a WDK signed
                  payout proof, not hidden custody.
                </Text>
              </View>

              <PrimaryButton
                label={
                  reward ? 'Reward distributed' : isResolved ? 'Result final' : 'Simulate match'
                }
                disabled={!isJoined || Boolean(reward) || isResolved}
                loading={isDistributing}
                onPress={simulateMatch}
              />
              <SecondaryButton label="Back to pools" onPress={() => router.back()} />
            </View>
          </GlassCard>
        </ScrollView>
      </Screen>
    </ProtectedRoute>
  );
}
