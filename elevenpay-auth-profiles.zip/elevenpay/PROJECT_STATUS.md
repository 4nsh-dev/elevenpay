# ElevenPay — Project Status

_Last updated: 7 July 2026 — auth flow connected to Supabase profiles._

## Snapshot

| Layer | Status |
| --- | --- |
| UI / design system / navigation | ✅ Built (untouched) |
| Authentication (Supabase Auth) | ✅ Built |
| **Auth ↔ Supabase profiles wiring** | ✅ **Done — this pass** |
| WDK wallet layer | ✅ Built (untouched) |
| Database schema (10 tables, FKs, indexes) | ✅ Done |
| Row Level Security (default-deny) | ✅ Done |
| Triggers (guards, profile bootstrap, settlement) | ✅ Done |
| Views (privacy shaping) | ✅ Done |
| RPCs (atomic money operations) | ✅ Done |
| Database types (`src/types/database.ts`) | ✅ Done |
| Seed data | ✅ Done |
| Repository/data-access layer | ✅ Done |
| Edge functions (submit-tx, resolve-pool, faucet) | ⏳ Next |
| Wiring features to repositories (replace mock data) | ⏳ Next |
| Realtime subscriptions | ⏳ Next |

## This pass: auth flow → Supabase profiles

### How it works

- **Profile creation after signup is automatic** — the
  `on_auth_user_created` database trigger inserts the `public.users` row the
  moment Supabase Auth creates the account (clients never create their own
  profile; there is deliberately no INSERT policy on `users`).
- **Profile fetch after login/signup** — `AuthBootstrap` already listened to
  `onAuthStateChange`; it now also runs `syncProfileAndWallet(userId)`, which
  fetches the profile through the repositories layer with a short backoff
  retry (absorbs the signup gap between session arrival and row readability).
  The fetched row overwrites auth-metadata `username`/`fullName` in the
  session store, so the displayed identity always matches the database —
  existing screens keep reading the same fields and need no changes.
- **Profile ↔ wallet link** — after the profile loads, if WDK has an
  on-device wallet for this user and no `wallets` row exists yet, the wallet
  address is registered via `wallets.registerWallet` (metadata only — no key
  material). Idempotent, tolerant of the unique-violation race, best-effort:
  a failure never blocks sign-in and retries on the next auth event.
- **Loading state** — `isProfileLoading` in the session store (alongside the
  existing `isBootstrapping`); set while fetching, cleared on success/error.
- **Error state** — `profileError` in the session store with friendly
  messages (network / expired session / still-provisioning); stale responses
  from a superseded session are discarded.
- **UI preserved** — no screen or component files touched. The new
  `useProfile()` hook (profile + loading + error + `refreshProfile`) is a
  purely additive export for future screens.

### Files changed in this pass

```
src/features/auth/profile-service.ts   (new — profile fetch/retry, wallet link, sync)
src/features/auth/use-profile.ts       (new — additive read hook)
src/features/auth/AuthBootstrap.tsx    (modified — runs profile sync on auth changes)
src/features/auth/index.ts             (modified — exports for the new service/hook)
src/stores/session.ts                  (modified — profile, isProfileLoading, profileError)
PROJECT_STATUS.md                      (updated)
```

Not modified: auth screens/schemas/actions (`auth-service.ts`,
`use-auth-actions.ts`, `ProtectedRoute.tsx`), all UI components, WDK
(`src/services/wdk`), wallet feature files, and everything else.

Depends on the previous pass: `src/services/supabase/repositories/*` and
`src/types/database.ts` (Supabase backend foundation).

## Previous pass: Supabase backend foundation

Seven ordered migrations (`supabase/migrations/`): extensions & helpers →
all 10 tables from `DATABASE.md` with FKs → 17 indexes (incl. partials) →
guard/bootstrap triggers → privacy views → default-deny RLS on every table →
atomic RPCs (`join_party`, `enter_pool`, `create_split`, `pay_split_leg`,
`resolve_pool`, `demo_faucet`, `resolve_wallet`). Plus `supabase/seed.sql`,
`supabase/config.toml`, full `src/types/database.ts`, and the typed
repository layer under `src/services/supabase/repositories/`.
See `supabase/README.md` for run/deploy instructions and the security model.

## How to apply

```bash
npx supabase start && npx supabase db reset   # local
# or
npx supabase link --project-ref <ref> && npx supabase db push   # hosted
```
