/**
 * Read hook for the signed-in user's Supabase profile.
 *
 * Purely additive — existing screens keep working off the session store
 * fields (username/fullName), which are kept in sync with the profile row.
 * New or updated screens can use this hook for the full profile plus
 * loading/error state.
 */

import { useSessionStore } from '@/stores/session';

import { refreshProfile } from './profile-service';

export function useProfile() {
  const profile = useSessionStore((state) => state.profile);
  const isProfileLoading = useSessionStore((state) => state.isProfileLoading);
  const profileError = useSessionStore((state) => state.profileError);

  return { profile, isProfileLoading, profileError, refreshProfile };
}
