import { create } from 'zustand';

import type { Tables } from '@/types/database';

type Profile = Tables<'users'>;

interface SessionState {
  userId: string | null;
  email: string | null;
  username: string | null;
  fullName: string | null;
  isAuthenticated: boolean;
  isBootstrapping: boolean;
  /** Supabase `users` profile row (source of truth once loaded). */
  profile: Profile | null;
  isProfileLoading: boolean;
  profileError: string | null;
  setSession: (session: {
    userId: string;
    email: string | null;
    username: string | null;
    fullName: string | null;
  }) => void;
  setBootstrapping: (isBootstrapping: boolean) => void;
  setProfileLoading: () => void;
  setProfile: (profile: Profile) => void;
  setProfileError: (profileError: string) => void;
  clearSession: () => void;
}

export const useSessionStore = create<SessionState>((set) => ({
  userId: null,
  email: null,
  username: null,
  fullName: null,
  isAuthenticated: false,
  isBootstrapping: true,
  profile: null,
  isProfileLoading: false,
  profileError: null,
  setSession: ({ userId, email, username, fullName }) =>
    set({ userId, email, username, fullName, isAuthenticated: true, isBootstrapping: false }),
  setBootstrapping: (isBootstrapping) => set({ isBootstrapping }),
  setProfileLoading: () => set({ isProfileLoading: true, profileError: null }),
  // The profile row wins over auth metadata so displayed identity always
  // matches the database (existing screens read username/fullName as before).
  setProfile: (profile) =>
    set({
      profile,
      username: profile.username,
      fullName: profile.full_name,
      isProfileLoading: false,
      profileError: null,
    }),
  setProfileError: (profileError) => set({ profileError, isProfileLoading: false }),
  clearSession: () =>
    set({
      userId: null,
      email: null,
      username: null,
      fullName: null,
      isAuthenticated: false,
      isBootstrapping: false,
      profile: null,
      isProfileLoading: false,
      profileError: null,
    }),
}));
