# ElevenPay — Project Status

_Last updated: 8 July 2026 — AI Copilot shipped (structured function calling, key-free)._

## Snapshot

| Area | Status |
| --- | --- |
| Supabase foundation (schema, RLS, RPCs, types, seeds, repositories) | ✅ Done |
| Auth ↔ profiles | ✅ Done |
| WDK wallet ↔ Supabase sync (addresses + balances, never keys) | ✅ Done |
| Persistent transaction storage (ledger + outbox) | ✅ Done |
| Watch parties (live data, join, payments) | ✅ Done |
| Prediction pools (create, join, simulate, payouts) | ✅ Done |
| Split bills (create, AI shares, requests, WDK payments, history) | ✅ Done |
| **AI Copilot (explain, summarize, prepare drafts, recommend)** | ✅ **Done — this pass** |
| Edge functions for on-chain verification | ⏳ Next |
| Realtime subscriptions | ⏳ Next |
| Guest share-link claim flow | ⏳ Next |

## This pass: AI Copilot

- **Never controls private keys** — read-only tools + unsigned drafts; signing stays in the WDK confirm sheet, and the copilot never imports WDK custody code.
- **Explain spending** — outgoing USDT by category with exact micro-USDT math (today / week / month).
- **Summarize transactions** — recent ledger lines with in/out totals and direction filters.
- **Prepare transfers** — @username -> `resolve_wallet` -> unsigned `PaymentDraft` -> `/confirm`.
- **Prepare split bills** — friends resolved, shares assigned by the share assistant, Split screen prefilled.
- **Recommend watch parties** — joinable parties ranked with grounded reasons.
- **Recommend prediction pools** — open pools ranked by closing time and pot.
- **Structured function calling** — `COPILOT_TOOLS` JSON contract + validated `ToolCall` execution; deterministic on-device planner, swappable for a hosted LLM.
- **Contextual, no generic chatbot** — live wallet context grounds the greeting, chips, and answers; off-domain prompts are refused with a scope message.

### Files changed in this pass

```
src/features/copilot/context.ts        (new)
src/features/copilot/tools.ts          (new)
src/features/copilot/planner.ts        (new)
src/features/copilot/use-copilot.ts    (new)
src/features/copilot/index.ts          (rewritten — was an empty stub)
src/stores/copilot.ts                  (new)
app/(tabs)/ai.tsx                      (rewritten — placeholder replaced)
app/split.tsx                          (modified — consumes copilot split prefill)
docs/ai-copilot.md                     (new)
PROJECT_STATUS.md                      (updated)
```

## Previous passes

- Supabase foundation — migrations, RLS, database types, seeds, repositories.
- Auth ↔ profiles — signup creates a profile, login hydrates it.
- Wallet sync — WDK addresses/balances registered in Supabase (docs/wallet-supabase-sync.md).
- Persistent transactions — PENDING -> BROADCAST ledger with offline outbox.
- Watch parties — live discovery, atomic joins, verified payments (docs/watch-party-supabase.md).
- Prediction pools — pools, entries, simulation, WDK payouts (docs/prediction-pools-supabase.md).
- Split bills — create, AI shares, requests, WDK payments, history (docs/split-bill-supabase.md).

## How to apply

- **No new migrations in this pass** — the copilot is app-layer only.
- Local: `npx supabase start` then `npx supabase db reset` (unchanged since the split-bill pass).
- Hosted: `npx supabase link` then `npx supabase db push`.
