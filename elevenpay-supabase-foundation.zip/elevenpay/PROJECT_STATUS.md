# ElevenPay — Project Status

_Last updated: 7 July 2026 — Supabase backend foundation implemented._

## Snapshot

| Layer | Status |
| --- | --- |
| UI / design system / navigation | ✅ Built (untouched in this pass) |
| Authentication (Supabase Auth) | ✅ Built (untouched in this pass) |
| WDK wallet layer | ✅ Built (untouched in this pass) |
| **Database schema (10 tables, FKs, indexes)** | ✅ **Done — this pass** |
| **Row Level Security (default-deny)** | ✅ **Done — this pass** |
| **Triggers (guards, profile bootstrap, settlement)** | ✅ **Done — this pass** |
| **Views (privacy shaping)** | ✅ **Done — this pass** |
| **RPCs (atomic money operations)** | ✅ **Done — this pass** |
| **Database types (`src/types/database.ts`)** | ✅ **Done — this pass** |
| **Seed data** | ✅ **Done — this pass** |
| **Repository/data-access layer** | ✅ **Done — this pass** |
| Edge functions (submit-tx, resolve-pool, faucet) | ⏳ Next |
| Wiring features to repositories (replace mock data) | ⏳ Next |
| Realtime subscriptions | ⏳ Next |

## What was implemented in this pass

### 1. Supabase directory (`supabase/`)

Seven ordered migrations, seed data, and local config:

- **0100 extensions & helpers** — pgcrypto; `set_updated_at()`,
  `is_service_role()`, `money_text()`.
- **0200 tables** — all 10 tables from `DATABASE.md` /
  `docs/database-design.md`: `users`, `wallets`, `transactions`, `matches`,
  `watch_parties`, `watch_party_members`, `prediction_pools`, `predictions`,
  `splits`, `split_members`. All money is `numeric(20,6)`, all timestamps
  `timestamptz`, all statuses CHECK-constrained, every FK has an explicit
  `ON DELETE` rule (RESTRICT on ledger endpoints).
- **0300 indexes** — 17 indexes incl. partials for hot paths
  (open transactions, upcoming parties, reservation expiry, owed legs,
  case-insensitive username search).
- **0400 triggers** — auth signup → profile bootstrap; email mirror;
  column guards (wallets balance-only, append-only transactions with legal
  status transitions, final picks, server-only PAID flips); prize-pool
  accrual; 24h remind rule; split auto-settlement.
- **0500 views** — `public_profiles` (no email), `party_attendance`,
  `party_attendee_previews`.
- **0600 RLS** — RLS enabled on all 10 tables, default-deny, `anon`
  revoked; policies per `docs/database-design.md` § "RLS policies" (incl.
  "picks hidden until pool closes", "clients insert PENDING only").
- **0700 RPCs** — `join_party` (atomic capacity + 3-min hold),
  `enter_pool` (one final pick), `create_split` (shares must sum to total),
  `pay_split_leg`, `resolve_pool` (service-role; payouts), `demo_faucet`
  (1/24h), `resolve_wallet` (username → address), `expire_party_reservations`.
  All money RPCs return the standard **payment template**
  `{ amount, receiver_wallet, type, reference_id }`.

### 2. Database types (`src/types/database.ts`)

Replaced the placeholder with the full generated-style `Database` type
(tables, views, functions) plus `Tables/TablesInsert/TablesUpdate/Views`
helpers and status/type unions. The existing typed client in
`src/services/supabase/client.ts` picks these up with no changes.

### 3. Repositories (`src/services/supabase/repositories/`)

Typed data-access layer for feature code: `profiles`, `wallets`,
`transactions`, `matches`, `watchParties`, `predictionPools`, `splits`
(+ shared `types` and a barrel `index.ts`). Repositories convert money to
decimal strings at the boundary and never touch keys or signing.

## Explicitly not modified (per constraints)

- **UI** — no changes to `src/components`, `src/features/**/screens`, or theme.
- **Authentication** — no changes to `src/features/auth` or the Supabase
  client/auth config.
- **WDK** — no changes to `src/services/wdk` or wallet flows.

## Created / updated files (this pass)

```
supabase/config.toml                                        (new)
supabase/README.md                                          (new)
supabase/seed.sql                                           (new)
supabase/migrations/20260707000100_extensions_and_helpers.sql (new)
supabase/migrations/20260707000200_tables.sql               (new)
supabase/migrations/20260707000300_indexes.sql              (new)
supabase/migrations/20260707000400_triggers.sql             (new)
supabase/migrations/20260707000500_views.sql                (new)
supabase/migrations/20260707000600_rls.sql                  (new)
supabase/migrations/20260707000700_functions.sql            (new)
src/types/database.ts                                       (replaced placeholder)
src/services/supabase/repositories/types.ts                 (new)
src/services/supabase/repositories/profiles.ts              (new)
src/services/supabase/repositories/wallets.ts               (new)
src/services/supabase/repositories/transactions.ts          (new)
src/services/supabase/repositories/matches.ts               (new)
src/services/supabase/repositories/watchParties.ts          (new)
src/services/supabase/repositories/predictionPools.ts       (new)
src/services/supabase/repositories/splits.ts                (new)
src/services/supabase/repositories/index.ts                 (new)
PROJECT_STATUS.md                                           (new)
```

## How to apply

```bash
npx supabase start && npx supabase db reset   # local
# or
npx supabase link --project-ref <ref> && npx supabase db push   # hosted
```

See `supabase/README.md` for details, demo accounts, and the security model.
