-- ============================================================================
-- ElevenPay seed data — LOCAL DEVELOPMENT / DEMO ONLY. Never run in production.
--
-- Creates demo auth users (password for all: "Password123!"), profiles,
-- wallets, matches, watch parties, prediction pools, predictions, a split,
-- and faucet transaction history.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) Demo auth users — the on_auth_user_created trigger builds public.users
-- ----------------------------------------------------------------------------
insert into auth.users (
  id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
  raw_app_meta_data, raw_user_meta_data, created_at, updated_at
)
values
  ('a0000000-0000-4000-8000-000000000001', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'treasury@elevenpay.demo',
   extensions.crypt('Password123!', extensions.gen_salt('bf')), now(),
   '{"provider":"email","providers":["email"]}', '{"full_name":"ElevenPay Treasury"}', now(), now()),
  ('a0000000-0000-4000-8000-000000000002', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'ansh@elevenpay.demo',
   extensions.crypt('Password123!', extensions.gen_salt('bf')), now(),
   '{"provider":"email","providers":["email"]}', '{"full_name":"Ansh"}', now(), now()),
  ('a0000000-0000-4000-8000-000000000003', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'alex@elevenpay.demo',
   extensions.crypt('Password123!', extensions.gen_salt('bf')), now(),
   '{"provider":"email","providers":["email"]}', '{"full_name":"Alex Turner"}', now(), now()),
  ('a0000000-0000-4000-8000-000000000004', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'john@elevenpay.demo',
   extensions.crypt('Password123!', extensions.gen_salt('bf')), now(),
   '{"provider":"email","providers":["email"]}', '{"full_name":"John Okafor"}', now(), now()),
  ('a0000000-0000-4000-8000-000000000005', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'emma@elevenpay.demo',
   extensions.crypt('Password123!', extensions.gen_salt('bf')), now(),
   '{"provider":"email","providers":["email"]}', '{"full_name":"Emma Silva"}', now(), now())
on conflict (id) do nothing;

-- Profile polish (trigger already created the rows).
update public.users set username = 'elevenpay_treasury' where id = 'a0000000-0000-4000-8000-000000000001';
update public.users set username = 'ansh', favorite_team = 'Argentina' where id = 'a0000000-0000-4000-8000-000000000002';
update public.users set username = 'alex', favorite_team = 'England' where id = 'a0000000-0000-4000-8000-000000000003';
update public.users set username = 'john', favorite_team = 'Nigeria' where id = 'a0000000-0000-4000-8000-000000000004';
update public.users set username = 'emma', favorite_team = 'Brazil' where id = 'a0000000-0000-4000-8000-000000000005';

-- ----------------------------------------------------------------------------
-- 2) Wallets (demo Sepolia addresses — metadata only, no key material, ever)
-- ----------------------------------------------------------------------------
insert into public.wallets (id, user_id, wallet_address, blockchain, balance, balance_updated_at)
values
  ('b0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000001',
   '0x1000000000000000000000000000000000000001', 'ethereum-sepolia', 10000, now()),
  ('b0000000-0000-4000-8000-000000000002', 'a0000000-0000-4000-8000-000000000002',
   '0x2000000000000000000000000000000000000002', 'ethereum-sepolia', 58.42, now()),
  ('b0000000-0000-4000-8000-000000000003', 'a0000000-0000-4000-8000-000000000003',
   '0x3000000000000000000000000000000000000003', 'ethereum-sepolia', 50, now()),
  ('b0000000-0000-4000-8000-000000000004', 'a0000000-0000-4000-8000-000000000004',
   '0x4000000000000000000000000000000000000004', 'ethereum-sepolia', 50, now()),
  ('b0000000-0000-4000-8000-000000000005', 'a0000000-0000-4000-8000-000000000005',
   '0x5000000000000000000000000000000000000005', 'ethereum-sepolia', 50, now())
on conflict (id) do nothing;

-- ----------------------------------------------------------------------------
-- 3) Matches
-- ----------------------------------------------------------------------------
insert into public.matches (id, team_a, team_b, kickoff_at, status)
values
  ('c0000000-0000-4000-8000-000000000001', 'Argentina', 'Brazil', now() + interval '2 days', 'SCHEDULED'),
  ('c0000000-0000-4000-8000-000000000002', 'England', 'France', now() + interval '5 days', 'SCHEDULED'),
  ('c0000000-0000-4000-8000-000000000003', 'Nigeria', 'Ghana', now() + interval '12 hours', 'SCHEDULED')
on conflict (id) do nothing;

-- ----------------------------------------------------------------------------
-- 4) Watch parties
-- ----------------------------------------------------------------------------
insert into public.watch_parties (
  id, organizer_id, match_id, title, venue, city, match_name,
  entry_fee, max_participants, event_date, status
)
values
  ('d0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000003',
   'c0000000-0000-4000-8000-000000000001', 'El Clasico de las Americas', 'Sky Lounge Rooftop', 'Delhi',
   'Argentina vs Brazil', 5, 40, now() + interval '2 days', 'OPEN'),
  ('d0000000-0000-4000-8000-000000000002', 'a0000000-0000-4000-8000-000000000004',
   'c0000000-0000-4000-8000-000000000002', 'Big Screen Derby Night', 'The Football Tavern', 'Mumbai',
   'England vs France', 3.5, 25, now() + interval '5 days', 'OPEN'),
  ('d0000000-0000-4000-8000-000000000003', 'a0000000-0000-4000-8000-000000000005',
   'c0000000-0000-4000-8000-000000000003', 'West African Showdown', 'Community Hall 7', 'Bengaluru',
   'Nigeria vs Ghana', 0, 60, now() + interval '12 hours', 'OPEN')
on conflict (id) do nothing;

-- Memberships: organizer + one paid guest at the first party.
insert into public.watch_party_members (id, watch_party_id, user_id, payment_status)
values
  ('d1000000-0000-4000-8000-000000000001', 'd0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000003', 'PAID'),
  ('d1000000-0000-4000-8000-000000000002', 'd0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000005', 'PAID')
on conflict (id) do nothing;

-- ----------------------------------------------------------------------------
-- 5) Prediction pools (+ picks; the trigger accrues prize_pool)
-- ----------------------------------------------------------------------------
insert into public.prediction_pools (
  id, match_id, watch_party_id, match_name, team_a, team_b,
  entry_fee, status, closes_at
)
values
  ('e0000000-0000-4000-8000-000000000001', 'c0000000-0000-4000-8000-000000000001',
   'd0000000-0000-4000-8000-000000000001', 'Argentina vs Brazil', 'Argentina', 'Brazil',
   2.5, 'OPEN', now() + interval '2 days'),
  ('e0000000-0000-4000-8000-000000000002', 'c0000000-0000-4000-8000-000000000003',
   null, 'Nigeria vs Ghana', 'Nigeria', 'Ghana',
   1, 'OPEN', now() + interval '11 hours')
on conflict (id) do nothing;

insert into public.predictions (id, pool_id, user_id, selected_team)
values
  ('e1000000-0000-4000-8000-000000000001', 'e0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000002', 'Argentina'),
  ('e1000000-0000-4000-8000-000000000002', 'e0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000005', 'Brazil'),
  ('e1000000-0000-4000-8000-000000000003', 'e0000000-0000-4000-8000-000000000002',
   'a0000000-0000-4000-8000-000000000004', 'Nigeria')
on conflict (id) do nothing;

-- ----------------------------------------------------------------------------
-- 6) A bill split: Ansh splits 100 with Alex, John, and Emma
-- ----------------------------------------------------------------------------
insert into public.splits (id, creator_id, total_amount, memo, status)
values
  ('f0000000-0000-4000-8000-000000000001', 'a0000000-0000-4000-8000-000000000002',
   100, 'Dinner at Olive', 'OPEN')
on conflict (id) do nothing;

insert into public.split_members (id, split_id, user_id, share_amount, status, paid_at)
values
  ('f1000000-0000-4000-8000-000000000001', 'f0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000002', 25, 'PAID', now()),
  ('f1000000-0000-4000-8000-000000000002', 'f0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000003', 25, 'REQUESTED', null),
  ('f1000000-0000-4000-8000-000000000003', 'f0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000004', 25, 'REQUESTED', null),
  ('f1000000-0000-4000-8000-000000000004', 'f0000000-0000-4000-8000-000000000001',
   'a0000000-0000-4000-8000-000000000005', 25, 'REQUESTED', null)
on conflict (id) do nothing;

-- ----------------------------------------------------------------------------
-- 7) Ledger history: faucet funding rows (server-minted SUCCESS)
-- ----------------------------------------------------------------------------
insert into public.transactions (
  id, sender_wallet, receiver_wallet, amount, type, status, memo, confirmed_at
)
values
  ('01000000-0000-4000-8000-000000000001', null, 'b0000000-0000-4000-8000-000000000002',
   50, 'FAUCET', 'SUCCESS', 'Demo faucet funding', now() - interval '2 days'),
  ('01000000-0000-4000-8000-000000000002', null, 'b0000000-0000-4000-8000-000000000003',
   50, 'FAUCET', 'SUCCESS', 'Demo faucet funding', now() - interval '2 days'),
  ('01000000-0000-4000-8000-000000000003', null, 'b0000000-0000-4000-8000-000000000004',
   50, 'FAUCET', 'SUCCESS', 'Demo faucet funding', now() - interval '1 day'),
  ('01000000-0000-4000-8000-000000000004', null, 'b0000000-0000-4000-8000-000000000005',
   50, 'FAUCET', 'SUCCESS', 'Demo faucet funding', now() - interval '1 day'),
  ('01000000-0000-4000-8000-000000000005', 'b0000000-0000-4000-8000-000000000002',
   'b0000000-0000-4000-8000-000000000003', 5, 'SEND', 'SUCCESS', 'For the kebabs', now() - interval '6 hours')
on conflict (id) do nothing;
