-- ============================================================================
-- 0700: RPCs — atomic multi-row money operations live server-side
--
-- Clients never orchestrate multi-step money state. Every join/entry/leg-pay
-- returns a PAYMENT TEMPLATE; the client then runs the standard pipeline:
-- create PENDING tx -> confirm sheet -> WDK sign -> submit hash (edge fn).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- treasury_wallet — receiver for pool entries (escrow stand-in for the demo)
-- ----------------------------------------------------------------------------
create or replace function public.treasury_wallet()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select w.id
  from public.wallets w
  join public.users u on u.id = w.user_id
  where u.username = 'elevenpay_treasury'
  limit 1;
$$;

-- ----------------------------------------------------------------------------
-- resolve_wallet — username -> address without exposing wallet rows
-- Same NOT-FOUND shape for "no such user" and "no wallet" (no enumeration).
-- ----------------------------------------------------------------------------
create or replace function public.resolve_wallet(p_username text)
returns table (
  user_id uuid,
  username text,
  wallet_address text,
  blockchain text
)
language sql
stable
security definer
set search_path = public
as $$
  select u.id, u.username, w.wallet_address, w.blockchain
  from public.users u
  join public.wallets w on w.user_id = u.id
  where lower(u.username) = lower(p_username)
  limit 1;
$$;

-- ----------------------------------------------------------------------------
-- expire_party_reservations — lazy sweep for the 3-minute seat hold
-- ----------------------------------------------------------------------------
create or replace function public.expire_party_reservations()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  v_count integer;
begin
  update public.watch_party_members
  set payment_status = 'EXPIRED'
  where payment_status = 'RESERVED'
    and reserved_until is not null
    and reserved_until < now();
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

-- ----------------------------------------------------------------------------
-- join_party — atomic capacity check + seat reservation
-- ----------------------------------------------------------------------------
create or replace function public.join_party(p_party_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_party public.watch_parties%rowtype;
  v_existing public.watch_party_members%rowtype;
  v_membership public.watch_party_members%rowtype;
  v_seats integer;
  v_receiver uuid;
  v_free boolean;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to join a party';
  end if;

  -- Serialize seat counting on the party row.
  select * into v_party from public.watch_parties where id = p_party_id for update;
  if not found then
    raise exception 'NOT_FOUND: watch party does not exist';
  end if;
  if v_party.status not in ('OPEN', 'FULL') then
    raise exception 'CONFLICT: party is not open for joining';
  end if;

  -- Lazy-expire stale seat holds for this party.
  update public.watch_party_members
  set payment_status = 'EXPIRED'
  where watch_party_id = p_party_id
    and payment_status = 'RESERVED'
    and reserved_until is not null
    and reserved_until < now();

  select * into v_existing
  from public.watch_party_members
  where watch_party_id = p_party_id and user_id = v_uid;

  if found and v_existing.payment_status in ('RESERVED', 'PAID') then
    raise exception 'ALREADY_EXISTS: you already have a seat in this party';
  end if;

  select count(*) into v_seats
  from public.watch_party_members
  where watch_party_id = p_party_id
    and payment_status in ('RESERVED', 'PAID');

  if v_seats >= v_party.max_participants then
    update public.watch_parties set status = 'FULL' where id = p_party_id and status = 'OPEN';
    raise exception 'PARTY_FULL: no seats left';
  end if;

  v_free := (v_party.entry_fee = 0);

  if found then
    -- Re-activate an EXPIRED/CANCELLED membership row (join-once unique key).
    update public.watch_party_members
    set payment_status = case when v_free then 'PAID' else 'RESERVED' end,
        reserved_until = case when v_free then null else now() + interval '3 minutes' end,
        transaction_id = null,
        joined_at = now()
    where id = v_existing.id
    returning * into v_membership;
  else
    insert into public.watch_party_members (watch_party_id, user_id, payment_status, reserved_until)
    values (
      p_party_id,
      v_uid,
      case when v_free then 'PAID' else 'RESERVED' end,
      case when v_free then null else now() + interval '3 minutes' end
    )
    returning * into v_membership;
  end if;

  select id into v_receiver from public.wallets where user_id = v_party.organizer_id limit 1;

  return jsonb_build_object(
    'membership_id', v_membership.id,
    'payment_status', v_membership.payment_status,
    'reserved_until', v_membership.reserved_until,
    'payment', case
      when v_free then null
      else jsonb_build_object(
        'amount', public.money_text(v_party.entry_fee),
        'receiver_wallet', v_receiver,
        'type', 'WATCH_PARTY',
        'reference_id', p_party_id
      )
    end
  );
end;
$$;

-- ----------------------------------------------------------------------------
-- enter_pool — one-pick check + payment template
-- ----------------------------------------------------------------------------
create or replace function public.enter_pool(p_pool_id uuid, p_selected_team text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_pool public.prediction_pools%rowtype;
  v_prediction_id uuid;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to enter a pool';
  end if;

  select * into v_pool from public.prediction_pools where id = p_pool_id for update;
  if not found then
    raise exception 'NOT_FOUND: prediction pool does not exist';
  end if;
  if v_pool.status <> 'OPEN' or now() >= v_pool.closes_at then
    raise exception 'POOL_CLOSED: entries are no longer accepted for this pool';
  end if;
  if p_selected_team not in (v_pool.team_a, v_pool.team_b) then
    raise exception 'VALIDATION_ERROR: selected_team must be one of the pool teams';
  end if;

  begin
    insert into public.predictions (pool_id, user_id, selected_team)
    values (p_pool_id, v_uid, p_selected_team)
    returning id into v_prediction_id;
  exception
    when unique_violation then
      raise exception 'ALREADY_EXISTS: one pick per pool, and picks are final';
  end;

  return jsonb_build_object(
    'prediction_id', v_prediction_id,
    'payment', jsonb_build_object(
      'amount', public.money_text(v_pool.entry_fee),
      'receiver_wallet', public.treasury_wallet(),
      'type', 'POOL_ENTRY',
      'reference_id', p_pool_id
    )
  );
end;
$$;

-- ----------------------------------------------------------------------------
-- create_split — split + legs atomically, shares must sum to total
-- Members payload: [{ "user_id": uuid, "share_amount": "25.000000" },
--                   { "self": true, "share_amount": "25.000000" },
--                   { "external_ref": "friend-token", "share_amount": "..." }]
-- ----------------------------------------------------------------------------
create or replace function public.create_split(
  p_total_amount numeric,
  p_memo text,
  p_members jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_member jsonb;
  v_share numeric(20, 6);
  v_sum numeric(20, 6) := 0;
  v_member_user uuid;
  v_seen_users uuid[] := '{}';
  v_split public.splits%rowtype;
  v_external_ref text;
  v_legs jsonb := '[]'::jsonb;
  v_leg public.split_members%rowtype;
  v_share_links jsonb := '[]'::jsonb;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to create a split';
  end if;
  if p_total_amount is null or p_total_amount <= 0 then
    raise exception 'VALIDATION_ERROR: total_amount must be positive';
  end if;
  if p_memo is not null and char_length(p_memo) > 140 then
    raise exception 'VALIDATION_ERROR: memo must be 140 characters or fewer';
  end if;
  if p_members is null or jsonb_typeof(p_members) <> 'array'
    or jsonb_array_length(p_members) < 1 or jsonb_array_length(p_members) > 20 then
    raise exception 'VALIDATION_ERROR: members must be an array of 1-20 entries';
  end if;

  -- Validate all legs and the sum before writing anything.
  for v_member in select * from jsonb_array_elements(p_members) loop
    v_share := nullif(v_member ->> 'share_amount', '')::numeric(20, 6);
    if v_share is null or v_share <= 0 then
      raise exception 'VALIDATION_ERROR: each share_amount must be a positive decimal string';
    end if;
    v_sum := v_sum + v_share;

    if coalesce((v_member ->> 'self')::boolean, false) then
      v_member_user := v_uid;
    elsif v_member ? 'user_id' and nullif(v_member ->> 'user_id', '') is not null then
      v_member_user := (v_member ->> 'user_id')::uuid;
      if not exists (select 1 from public.users u where u.id = v_member_user) then
        raise exception 'NOT_FOUND: unknown member user_id %', v_member_user;
      end if;
    else
      v_member_user := null; -- external friend via share link
    end if;

    if v_member_user is not null then
      if v_member_user = any (v_seen_users) then
        raise exception 'VALIDATION_ERROR: duplicate member %', v_member_user;
      end if;
      v_seen_users := array_append(v_seen_users, v_member_user);
    end if;
  end loop;

  if v_sum <> p_total_amount then
    raise exception 'VALIDATION_ERROR: shares must sum to total (% unassigned)',
      public.money_text(p_total_amount - v_sum);
  end if;

  insert into public.splits (creator_id, total_amount, memo)
  values (v_uid, p_total_amount, p_memo)
  returning * into v_split;

  for v_member in select * from jsonb_array_elements(p_members) loop
    v_share := (v_member ->> 'share_amount')::numeric(20, 6);

    if coalesce((v_member ->> 'self')::boolean, false) then
      -- Creator's own leg is settled immediately.
      insert into public.split_members (split_id, user_id, share_amount, status, paid_at)
      values (v_split.id, v_uid, v_share, 'PAID', now())
      returning * into v_leg;
    elsif v_member ? 'user_id' and nullif(v_member ->> 'user_id', '') is not null then
      insert into public.split_members (split_id, user_id, share_amount)
      values (v_split.id, (v_member ->> 'user_id')::uuid, v_share)
      returning * into v_leg;
    else
      v_external_ref := coalesce(
        nullif(v_member ->> 'external_ref', ''),
        encode(extensions.gen_random_bytes(16), 'hex')
      );
      insert into public.split_members (split_id, external_ref, share_amount)
      values (v_split.id, v_external_ref, v_share)
      returning * into v_leg;
      v_share_links := v_share_links || jsonb_build_object(
        'leg_id', v_leg.id,
        'external_ref', v_external_ref
      );
    end if;

    v_legs := v_legs || jsonb_build_object(
      'leg_id', v_leg.id,
      'user_id', v_leg.user_id,
      'external_ref', v_leg.external_ref,
      'share_amount', public.money_text(v_leg.share_amount),
      'status', v_leg.status
    );
  end loop;

  return jsonb_build_object(
    'split_id', v_split.id,
    'status', v_split.status,
    'total_amount', public.money_text(v_split.total_amount),
    'memo', v_split.memo,
    'legs', v_legs,
    'share_links', v_share_links
  );
end;
$$;

-- ----------------------------------------------------------------------------
-- pay_split_leg — member accepts their leg -> standard payment template
-- ----------------------------------------------------------------------------
create or replace function public.pay_split_leg(p_leg_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_leg public.split_members%rowtype;
  v_split public.splits%rowtype;
  v_receiver uuid;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to pay a split';
  end if;

  select * into v_leg from public.split_members where id = p_leg_id for update;
  if not found then
    raise exception 'NOT_FOUND: split leg does not exist';
  end if;
  if v_leg.user_id is distinct from v_uid then
    raise exception 'FORBIDDEN: this is not your leg';
  end if;
  if v_leg.status <> 'REQUESTED' then
    raise exception 'CONFLICT: leg is already % ', v_leg.status;
  end if;

  select * into v_split from public.splits where id = v_leg.split_id;
  if v_split.status <> 'OPEN' then
    raise exception 'CONFLICT: split is %', v_split.status;
  end if;

  select id into v_receiver from public.wallets where user_id = v_split.creator_id limit 1;
  if v_receiver is null then
    raise exception 'CONFLICT: split creator has no registered wallet';
  end if;

  return jsonb_build_object(
    'leg_id', v_leg.id,
    'payment', jsonb_build_object(
      'amount', public.money_text(v_leg.share_amount),
      'receiver_wallet', v_receiver,
      'type', 'SPLIT_BILL',
      'reference_id', v_split.id
    )
  );
end;
$$;

-- ----------------------------------------------------------------------------
-- resolve_pool — demo resolution + payout creation (service role only;
-- called from the resolve-pool edge function)
-- ----------------------------------------------------------------------------
create or replace function public.resolve_pool(
  p_pool_id uuid,
  p_winner_team text default null,
  p_simulate boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_pool public.prediction_pools%rowtype;
  v_winner text;
  v_entries integer;
  v_prize numeric(20, 6);
  v_winner_count integer;
  v_payout numeric(20, 6);
  v_tx_ids uuid[] := '{}';
  v_winner_ids uuid[];
  v_tx_id uuid;
  v_rec record;
begin
  if not public.is_service_role() then
    raise exception 'FORBIDDEN: resolve_pool is service-role only';
  end if;

  select * into v_pool from public.prediction_pools where id = p_pool_id for update;
  if not found then
    raise exception 'NOT_FOUND: prediction pool does not exist';
  end if;
  if v_pool.status = 'FINISHED' then
    raise exception 'CONFLICT: pool is already resolved';
  end if;

  if p_simulate and p_winner_team is null then
    v_winner := case when random() < 0.5 then v_pool.team_a else v_pool.team_b end;
  else
    v_winner := p_winner_team;
  end if;
  if v_winner is null or v_winner not in (v_pool.team_a, v_pool.team_b) then
    raise exception 'VALIDATION_ERROR: winner_team must be one of the pool teams';
  end if;

  -- Derive the truth from predictions (denormalized prize_pool is display only).
  select count(*) into v_entries from public.predictions where pool_id = p_pool_id;
  v_prize := v_entries * v_pool.entry_fee;

  update public.predictions
  set is_winner = (selected_team = v_winner)
  where pool_id = p_pool_id;

  select count(*), coalesce(array_agg(user_id), '{}')
  into v_winner_count, v_winner_ids
  from public.predictions
  where pool_id = p_pool_id and is_winner;

  v_payout := case when v_winner_count > 0 then round(v_prize / v_winner_count, 6) else 0 end;

  -- Mint POOL_REWARD ledger rows from the treasury to each winner's wallet.
  if v_winner_count > 0 and v_payout > 0 then
    for v_rec in
      select p.user_id, w.id as wallet_id
      from public.predictions p
      join public.wallets w on w.user_id = p.user_id
      where p.pool_id = p_pool_id and p.is_winner
    loop
      insert into public.transactions (
        sender_wallet, receiver_wallet, amount, type, status, reference_id, memo, confirmed_at
      )
      values (
        public.treasury_wallet(), v_rec.wallet_id, v_payout, 'POOL_REWARD', 'SUCCESS',
        p_pool_id, 'Prediction pool payout', now()
      )
      returning id into v_tx_id;
      v_tx_ids := array_append(v_tx_ids, v_tx_id);

      update public.wallets
      set balance = balance + v_payout, balance_updated_at = now()
      where id = v_rec.wallet_id;
    end loop;
  end if;

  if v_pool.match_id is not null then
    update public.matches
    set status = 'FINISHED', winner_team = v_winner
    where id = v_pool.match_id;
  end if;

  update public.prediction_pools
  set status = 'FINISHED',
      winner_team = v_winner,
      prize_pool = v_prize,
      resolved_at = now()
  where id = p_pool_id;

  return jsonb_build_object(
    'status', 'FINISHED',
    'winner_team', v_winner,
    'winners', to_jsonb(v_winner_ids),
    'payout_per_winner', public.money_text(v_payout),
    'payout_transaction_ids', to_jsonb(v_tx_ids)
  );
end;
$$;

-- ----------------------------------------------------------------------------
-- demo_faucet — demo USDT funding path (1 per 24h per user)
-- ----------------------------------------------------------------------------
create or replace function public.demo_faucet()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_wallet public.wallets%rowtype;
  v_amount numeric(20, 6) := 50;
  v_tx_id uuid;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to use the faucet';
  end if;

  select * into v_wallet from public.wallets where user_id = v_uid limit 1;
  if not found then
    raise exception 'NOT_FOUND: register a wallet first';
  end if;

  if exists (
    select 1 from public.transactions
    where receiver_wallet = v_wallet.id
      and type = 'FAUCET'
      and created_at > now() - interval '24 hours'
  ) then
    raise exception 'RATE_LIMITED: faucet is available once per day';
  end if;

  insert into public.transactions (
    sender_wallet, receiver_wallet, amount, type, status, memo, confirmed_at
  )
  values (null, v_wallet.id, v_amount, 'FAUCET', 'SUCCESS', 'Demo faucet funding', now())
  returning id into v_tx_id;

  update public.wallets
  set balance = balance + v_amount, balance_updated_at = now()
  where id = v_wallet.id;

  return jsonb_build_object(
    'transaction_id', v_tx_id,
    'amount', public.money_text(v_amount),
    'status', 'SUCCESS'
  );
end;
$$;

-- ----------------------------------------------------------------------------
-- Grants — default-deny, then explicit execute rights
-- ----------------------------------------------------------------------------
revoke execute on all functions in schema public from public, anon;

grant execute on function public.resolve_wallet(text) to authenticated, service_role;
grant execute on function public.join_party(uuid) to authenticated, service_role;
grant execute on function public.enter_pool(uuid, text) to authenticated, service_role;
grant execute on function public.create_split(numeric, text, jsonb) to authenticated, service_role;
grant execute on function public.pay_split_leg(uuid) to authenticated, service_role;
grant execute on function public.demo_faucet() to authenticated, service_role;
grant execute on function public.expire_party_reservations() to authenticated, service_role;
grant execute on function public.resolve_pool(uuid, text, boolean) to service_role;
