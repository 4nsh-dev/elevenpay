-- ============================================================================
-- 0400: Triggers — auth profile bootstrap, column guards, derived state
--
-- Guard philosophy: RLS decides WHO can touch a row; these triggers decide
-- WHAT they may change. Together they enforce "clients may claim intent,
-- only the server may claim success".
-- ============================================================================

-- ----------------------------------------------------------------------------
-- updated_at maintenance
-- ----------------------------------------------------------------------------
create trigger users_set_updated_at
  before update on public.users
  for each row execute function public.set_updated_at();

create trigger watch_parties_set_updated_at
  before update on public.watch_parties
  for each row execute function public.set_updated_at();

create trigger prediction_pools_set_updated_at
  before update on public.prediction_pools
  for each row execute function public.set_updated_at();

create trigger splits_set_updated_at
  before update on public.splits
  for each row execute function public.set_updated_at();

-- ----------------------------------------------------------------------------
-- auth.users -> public.users profile bootstrap
-- (never trust the client to create its own profile row)
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(
      nullif(new.raw_user_meta_data ->> 'full_name', ''),
      split_part(coalesce(new.email, 'football fan'), '@', 1)
    ),
    new.raw_user_meta_data ->> 'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_auth_user();

-- Mirror auth email changes into the profile row.
create or replace function public.handle_auth_user_email_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.users set email = new.email where id = new.id;
  return new;
end;
$$;

create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row
  when (old.email is distinct from new.email)
  execute function public.handle_auth_user_email_change();

-- ----------------------------------------------------------------------------
-- users guard: id immutable; email managed by auth, not by clients
-- ----------------------------------------------------------------------------
create or replace function public.users_guard()
returns trigger
language plpgsql
as $$
begin
  if new.id <> old.id then
    raise exception 'users.id is immutable';
  end if;
  if not public.is_service_role() and new.email is distinct from old.email then
    raise exception 'users.email is managed by auth and cannot be changed directly';
  end if;
  return new;
end;
$$;

create trigger users_guard
  before update on public.users
  for each row execute function public.users_guard();

-- ----------------------------------------------------------------------------
-- wallets guard: clients may only refresh the balance cache; address and
-- chain are immutable once registered
-- ----------------------------------------------------------------------------
create or replace function public.wallets_guard()
returns trigger
language plpgsql
as $$
begin
  if not public.is_service_role() then
    if new.id <> old.id
      or new.user_id <> old.user_id
      or new.wallet_address <> old.wallet_address
      or new.blockchain <> old.blockchain
      or new.created_at <> old.created_at then
      raise exception 'only balance and balance_updated_at are updatable on wallets';
    end if;
  end if;
  if new.balance is distinct from old.balance and new.balance_updated_at is not distinct from old.balance_updated_at then
    new.balance_updated_at := now();
  end if;
  return new;
end;
$$;

create trigger wallets_guard
  before update on public.wallets
  for each row execute function public.wallets_guard();

-- ----------------------------------------------------------------------------
-- transactions: append-only ledger discipline
-- ----------------------------------------------------------------------------
create or replace function public.transactions_guard()
returns trigger
language plpgsql
as $$
begin
  -- Core columns are immutable; only status-transition columns may change.
  if new.id <> old.id
    or new.sender_wallet is distinct from old.sender_wallet
    or new.receiver_wallet is distinct from old.receiver_wallet
    or new.amount <> old.amount
    or new.currency <> old.currency
    or new.type <> old.type
    or new.reference_id is distinct from old.reference_id
    or new.idempotency_key is distinct from old.idempotency_key
    or new.created_at <> old.created_at then
    raise exception 'transactions are append-only; only status transition columns may change';
  end if;

  -- Legal status transitions: PENDING -> BROADCAST -> SUCCESS | FAILED
  -- (PENDING may also fail/succeed directly for same-step verification).
  if not (
    (old.status = 'PENDING' and new.status in ('PENDING', 'BROADCAST', 'SUCCESS', 'FAILED'))
    or (old.status = 'BROADCAST' and new.status in ('BROADCAST', 'SUCCESS', 'FAILED'))
    or (old.status in ('SUCCESS', 'FAILED') and new.status = old.status)
  ) then
    raise exception 'illegal transaction status transition: % -> %', old.status, new.status;
  end if;

  if new.status = 'SUCCESS' and new.confirmed_at is null then
    new.confirmed_at := now();
  end if;

  return new;
end;
$$;

create trigger transactions_guard
  before update on public.transactions
  for each row execute function public.transactions_guard();

create or replace function public.transactions_block_delete()
returns trigger
language plpgsql
as $$
begin
  raise exception 'transactions are append-only; deletes are not allowed';
end;
$$;

create trigger transactions_block_delete
  before delete on public.transactions
  for each row execute function public.transactions_block_delete();

-- ----------------------------------------------------------------------------
-- predictions: cross-row validation, finality, prize pool maintenance
-- ----------------------------------------------------------------------------

-- Pick must be one of the pool's teams; entries only while pool is OPEN and
-- before closes_at (server clock, not client clock).
create or replace function public.predictions_validate()
returns trigger
language plpgsql
as $$
declare
  v_pool public.prediction_pools%rowtype;
begin
  select * into v_pool
  from public.prediction_pools
  where id = new.pool_id
  for update;

  if not found then
    raise exception 'NOT_FOUND: prediction pool does not exist';
  end if;
  if v_pool.status <> 'OPEN' or now() >= v_pool.closes_at then
    raise exception 'POOL_CLOSED: entries are no longer accepted for this pool';
  end if;
  if new.selected_team not in (v_pool.team_a, v_pool.team_b) then
    raise exception 'VALIDATION_ERROR: selected_team must be one of the pool teams';
  end if;
  if new.is_winner is not null and not public.is_service_role() then
    raise exception 'FORBIDDEN: is_winner is set by the server only';
  end if;
  return new;
end;
$$;

create trigger predictions_validate
  before insert on public.predictions
  for each row execute function public.predictions_validate();

-- Picks are final: no client updates at all; service role may set is_winner
-- and receipt link only.
create or replace function public.predictions_guard()
returns trigger
language plpgsql
as $$
begin
  if not public.is_service_role() then
    raise exception 'FORBIDDEN: picks are final';
  end if;
  if new.id <> old.id
    or new.pool_id <> old.pool_id
    or new.user_id <> old.user_id
    or new.selected_team <> old.selected_team
    or new.created_at <> old.created_at then
    raise exception 'only is_winner and transaction_id may change on predictions';
  end if;
  return new;
end;
$$;

create trigger predictions_guard
  before update on public.predictions
  for each row execute function public.predictions_guard();

-- Denormalized prize pool moves with each entry.
create or replace function public.predictions_prize_pool()
returns trigger
language plpgsql
as $$
begin
  update public.prediction_pools
  set prize_pool = prize_pool + entry_fee
  where id = new.pool_id;
  return new;
end;
$$;

create trigger predictions_prize_pool
  after insert on public.predictions
  for each row execute function public.predictions_prize_pool();

-- ----------------------------------------------------------------------------
-- watch_party_members guard: RESERVED -> PAID flips are service-role only
-- (tied to a verified transaction); users may cancel their own reservation
-- ----------------------------------------------------------------------------
create or replace function public.watch_party_members_guard()
returns trigger
language plpgsql
as $$
begin
  if new.id <> old.id
    or new.watch_party_id <> old.watch_party_id
    or new.user_id <> old.user_id
    or new.joined_at <> old.joined_at then
    raise exception 'watch_party_members identity columns are immutable';
  end if;
  if not public.is_service_role() then
    if new.payment_status = 'PAID' and old.payment_status <> 'PAID' then
      raise exception 'FORBIDDEN: PAID is set by the server after payment verification';
    end if;
    if new.transaction_id is distinct from old.transaction_id then
      raise exception 'FORBIDDEN: receipt links are set by the server';
    end if;
  end if;
  return new;
end;
$$;

create trigger watch_party_members_guard
  before update on public.watch_party_members
  for each row execute function public.watch_party_members_guard();

-- ----------------------------------------------------------------------------
-- split_members: guards (PAID via server, 24h remind rule) + auto-settlement
-- ----------------------------------------------------------------------------
create or replace function public.split_members_guard()
returns trigger
language plpgsql
as $$
begin
  if new.id <> old.id
    or new.split_id <> old.split_id
    or new.user_id is distinct from old.user_id
    or new.share_amount <> old.share_amount
    or new.created_at <> old.created_at then
    raise exception 'split_members identity columns are immutable';
  end if;

  if not public.is_service_role() then
    if new.status = 'PAID' and old.status <> 'PAID' then
      raise exception 'FORBIDDEN: PAID is set by the server after payment verification';
    end if;
    if new.transaction_id is distinct from old.transaction_id then
      raise exception 'FORBIDDEN: receipt links are set by the server';
    end if;
  end if;

  -- Once-per-24h remind rule.
  if new.reminded_at is distinct from old.reminded_at then
    if old.reminded_at is not null and old.reminded_at > now() - interval '24 hours' then
      raise exception 'RATE_LIMITED: legs can be reminded once per 24 hours';
    end if;
  end if;

  if new.status = 'PAID' and old.status <> 'PAID' and new.paid_at is null then
    new.paid_at := now();
  end if;

  return new;
end;
$$;

create trigger split_members_guard
  before update on public.split_members
  for each row execute function public.split_members_guard();

-- SETTLED flips by trigger when the last leg pays.
create or replace function public.split_members_settle()
returns trigger
language plpgsql
as $$
begin
  if new.status = 'PAID' and old.status <> 'PAID' then
    update public.splits s
    set status = 'SETTLED'
    where s.id = new.split_id
      and s.status = 'OPEN'
      and not exists (
        select 1
        from public.split_members sm
        where sm.split_id = new.split_id
          and sm.status = 'REQUESTED'
      );
  end if;
  return new;
end;
$$;

create trigger split_members_settle
  after update on public.split_members
  for each row execute function public.split_members_settle();
