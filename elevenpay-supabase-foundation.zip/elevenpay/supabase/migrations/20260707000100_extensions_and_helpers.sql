-- ============================================================================
-- 0100: Extensions and shared helper functions
-- ============================================================================

create extension if not exists pgcrypto with schema extensions;

-- Maintains updated_at on mutable tables.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- True when the caller is privileged (edge functions / service role / db owner).
-- Used by guard triggers to separate "client may claim intent" from
-- "server may claim success".
create or replace function public.is_service_role()
returns boolean
language sql
stable
as $$
  select
    coalesce(current_setting('request.jwt.claims', true)::jsonb ->> 'role', '') = 'service_role'
    or current_user in ('service_role', 'postgres', 'supabase_admin');
$$;

-- Formats numeric(20,6) money values as fixed 6-decimal strings for payment
-- templates (amounts travel as decimal strings in API/client code).
create or replace function public.money_text(p_amount numeric)
returns text
language sql
immutable
as $$
  select to_char(p_amount, 'FM999999999999990.000000');
$$;
