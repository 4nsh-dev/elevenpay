-- ============================================================================
-- 0600: Row Level Security — default-deny; the policies below are the only holes
--
-- Roles: authenticated (app users), service_role (edge functions — bypasses
-- RLS). No policy grants anon anything.
-- ============================================================================

-- Default deny: strip anon table access entirely.
revoke all on all tables in schema public from anon;

alter table public.users enable row level security;
alter table public.wallets enable row level security;
alter table public.transactions enable row level security;
alter table public.matches enable row level security;
alter table public.watch_parties enable row level security;
alter table public.watch_party_members enable row level security;
alter table public.prediction_pools enable row level security;
alter table public.predictions enable row level security;
alter table public.splits enable row level security;
alter table public.split_members enable row level security;

-- ----------------------------------------------------------------------------
-- users: own row only (public discovery goes through public_profiles view)
-- INSERT/DELETE: none — auth trigger creates; account deletion cascades.
-- ----------------------------------------------------------------------------
create policy users_select_own
  on public.users for select to authenticated
  using (id = (select auth.uid()));

create policy users_update_own
  on public.users for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- ----------------------------------------------------------------------------
-- wallets: own rows; address lookup for sending uses the resolve_wallet RPC
-- UPDATE is constrained to balance columns by the wallets_guard trigger.
-- DELETE: none.
-- ----------------------------------------------------------------------------
create policy wallets_select_own
  on public.wallets for select to authenticated
  using (user_id = (select auth.uid()));

create policy wallets_insert_own
  on public.wallets for insert to authenticated
  with check (user_id = (select auth.uid()));

create policy wallets_update_own
  on public.wallets for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- ----------------------------------------------------------------------------
-- transactions: visible to either endpoint owner; clients may only insert
-- PENDING intents from their own wallet; status flips are service-role only
-- (no UPDATE/DELETE policies for authenticated — and triggers back this up).
-- FAUCET and POOL_REWARD rows are minted by the server.
-- ----------------------------------------------------------------------------
create policy transactions_select_own
  on public.transactions for select to authenticated
  using (
    exists (
      select 1 from public.wallets w
      where w.id = transactions.sender_wallet
        and w.user_id = (select auth.uid())
    )
    or exists (
      select 1 from public.wallets w
      where w.id = transactions.receiver_wallet
        and w.user_id = (select auth.uid())
    )
  );

create policy transactions_insert_pending_own
  on public.transactions for insert to authenticated
  with check (
    status = 'PENDING'
    and transaction_hash is null
    and confirmed_at is null
    and type in ('SEND', 'WATCH_PARTY', 'POOL_ENTRY', 'SPLIT_BILL', 'TIP')
    and sender_wallet is not null
    and exists (
      select 1 from public.wallets w
      where w.id = sender_wallet
        and w.user_id = (select auth.uid())
    )
  );

-- ----------------------------------------------------------------------------
-- matches: readable by all authenticated; writes are service role only
-- ----------------------------------------------------------------------------
create policy matches_select_all
  on public.matches for select to authenticated
  using (true);

-- ----------------------------------------------------------------------------
-- watch_parties: public discovery; organizers manage their own (not after PAST)
-- DELETE: none — CANCELLED status instead.
-- ----------------------------------------------------------------------------
create policy watch_parties_select_all
  on public.watch_parties for select to authenticated
  using (true);

create policy watch_parties_insert_organizer
  on public.watch_parties for insert to authenticated
  with check (organizer_id = (select auth.uid()));

create policy watch_parties_update_organizer
  on public.watch_parties for update to authenticated
  using (organizer_id = (select auth.uid()) and status <> 'PAST')
  with check (organizer_id = (select auth.uid()));

-- ----------------------------------------------------------------------------
-- watch_party_members: own memberships, or memberships of parties the user
-- organizes; aggregate counts go through the party_attendance view.
-- INSERT: self only, RESERVED, via join_party RPC (capacity-checked).
-- UPDATE: user may cancel own RESERVED row; PAID flips via service role.
-- DELETE: none — EXPIRED/CANCELLED by status.
-- ----------------------------------------------------------------------------
create policy watch_party_members_select
  on public.watch_party_members for select to authenticated
  using (
    user_id = (select auth.uid())
    or exists (
      select 1 from public.watch_parties wp
      where wp.id = watch_party_members.watch_party_id
        and wp.organizer_id = (select auth.uid())
    )
  );

create policy watch_party_members_insert_self_reserved
  on public.watch_party_members for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and payment_status = 'RESERVED'
  );

create policy watch_party_members_cancel_own_reserved
  on public.watch_party_members for update to authenticated
  using (
    user_id = (select auth.uid())
    and payment_status = 'RESERVED'
  )
  with check (
    user_id = (select auth.uid())
    and payment_status in ('RESERVED', 'CANCELLED')
  );

-- ----------------------------------------------------------------------------
-- prediction_pools: readable by all authenticated; pools are seeded/resolved
-- by the system (service role). DELETE: none — CANCELLED status.
-- ----------------------------------------------------------------------------
create policy prediction_pools_select_all
  on public.prediction_pools for select to authenticated
  using (true);

-- ----------------------------------------------------------------------------
-- predictions: own rows always; other users'' picks only after the pool
-- closes (no copying picks — enforced in policy, not UI).
-- INSERT: self only (validation trigger enforces OPEN + closes_at + teams;
-- unique constraint enforces one pick). UPDATE/DELETE: none for clients.
-- ----------------------------------------------------------------------------
create policy predictions_select_own_or_closed
  on public.predictions for select to authenticated
  using (
    user_id = (select auth.uid())
    or exists (
      select 1 from public.prediction_pools p
      where p.id = predictions.pool_id
        and p.status <> 'OPEN'
    )
  );

create policy predictions_insert_self
  on public.predictions for insert to authenticated
  with check (user_id = (select auth.uid()));

-- ----------------------------------------------------------------------------
-- splits: visible to creator or members; created via create_split RPC;
-- creator may cancel while OPEN (SETTLED flips by trigger). DELETE: none.
-- ----------------------------------------------------------------------------
create policy splits_select_creator_or_member
  on public.splits for select to authenticated
  using (
    creator_id = (select auth.uid())
    or exists (
      select 1 from public.split_members sm
      where sm.split_id = splits.id
        and sm.user_id = (select auth.uid())
    )
  );

create policy splits_insert_creator
  on public.splits for insert to authenticated
  with check (creator_id = (select auth.uid()));

create policy splits_update_creator_cancel
  on public.splits for update to authenticated
  using (creator_id = (select auth.uid()) and status = 'OPEN')
  with check (
    creator_id = (select auth.uid())
    and status in ('OPEN', 'CANCELLED')
  );

-- ----------------------------------------------------------------------------
-- split_members: visible to the member or the split''s creator.
-- INSERT: only via the create_split RPC (security definer — no client policy).
-- UPDATE: creator may cancel a leg / bump reminded_at (24h trigger guard);
-- PAID flips via service role. DELETE: none.
-- ----------------------------------------------------------------------------
create policy split_members_select_member_or_creator
  on public.split_members for select to authenticated
  using (
    user_id = (select auth.uid())
    or exists (
      select 1 from public.splits s
      where s.id = split_members.split_id
        and s.creator_id = (select auth.uid())
    )
  );

create policy split_members_update_creator
  on public.split_members for update to authenticated
  using (
    exists (
      select 1 from public.splits s
      where s.id = split_members.split_id
        and s.creator_id = (select auth.uid())
    )
  )
  with check (
    exists (
      select 1 from public.splits s
      where s.id = split_members.split_id
        and s.creator_id = (select auth.uid())
    )
    and status in ('REQUESTED', 'CANCELLED')
  );
