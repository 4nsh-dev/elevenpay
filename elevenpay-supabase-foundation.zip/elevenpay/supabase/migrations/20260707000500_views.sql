-- ============================================================================
-- 0500: Views — privacy shaping
-- Expose aggregates and safe columns instead of loosening table policies.
-- Views are owned by postgres (definer semantics) on purpose: they are the
-- sanctioned holes through default-deny RLS. anon gets nothing.
-- ============================================================================

-- Public discovery profile: never exposes email.
create view public.public_profiles as
select
  id,
  username,
  full_name,
  avatar_url,
  favorite_team
from public.users;

comment on view public.public_profiles is
  'Safe columns of users for friend search and attendee/participant displays. Email is never exposed to other users.';

-- Seat counts per party without exposing other members'' payment status.
create view public.party_attendance as
select
  wp.id as watch_party_id,
  wp.max_participants,
  count(m.id) filter (where m.payment_status in ('RESERVED', 'PAID'))::integer as seats_taken,
  greatest(
    wp.max_participants
      - count(m.id) filter (where m.payment_status in ('RESERVED', 'PAID'))::integer,
    0
  ) as seats_left
from public.watch_parties wp
left join public.watch_party_members m on m.watch_party_id = wp.id
group by wp.id, wp.max_participants;

comment on view public.party_attendance is
  'Aggregate seat availability per watch party (avatars + count pattern).';

-- Attendee avatar previews: public profile fields only.
create view public.party_attendee_previews as
select
  m.watch_party_id,
  m.joined_at,
  p.id as user_id,
  p.username,
  p.full_name,
  p.avatar_url
from public.watch_party_members m
join public.users p on p.id = m.user_id
where m.payment_status in ('RESERVED', 'PAID');

comment on view public.party_attendee_previews is
  'Who is going (public profile fields only) — payment status is not exposed.';

-- Grants: authenticated only; default-deny for anon.
revoke all on public.public_profiles from public, anon;
revoke all on public.party_attendance from public, anon;
revoke all on public.party_attendee_previews from public, anon;

grant select on public.public_profiles to authenticated, service_role;
grant select on public.party_attendance to authenticated, service_role;
grant select on public.party_attendee_previews to authenticated, service_role;
