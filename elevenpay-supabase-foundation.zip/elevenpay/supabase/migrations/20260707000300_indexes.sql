-- ============================================================================
-- 0300: Indexes — beyond automatic PK/UNIQUE indexes
-- Composite before single, partial where the hot query has a fixed predicate.
-- ============================================================================

-- Wallet lookup at session start.
create index wallets_user_id_idx
  on public.wallets (user_id);

-- Outbound history, newest first.
create index transactions_sender_created_idx
  on public.transactions (sender_wallet, created_at desc);

-- Inbound history, newest first.
create index transactions_receiver_created_idx
  on public.transactions (receiver_wallet, created_at desc);

-- "Show payments for this pool/party/split".
create index transactions_reference_idx
  on public.transactions (reference_id);

-- Partial: confirmation worker scans only open transactions.
create index transactions_open_status_idx
  on public.transactions (status)
  where status in ('PENDING', 'BROADCAST');

-- Partial: upcoming-parties list.
create index watch_parties_upcoming_idx
  on public.watch_parties (event_date)
  where status = 'OPEN';

-- Nearby filter.
create index watch_parties_city_idx
  on public.watch_parties (city);

-- Attendee lists + seat counting.
create index watch_party_members_party_idx
  on public.watch_party_members (watch_party_id);

-- "My parties".
create index watch_party_members_user_idx
  on public.watch_party_members (user_id);

-- Partial: reservation expiry sweep.
create index watch_party_members_expiry_idx
  on public.watch_party_members (reserved_until)
  where payment_status = 'RESERVED';

-- Open-pools feed.
create index prediction_pools_feed_idx
  on public.prediction_pools (status, closes_at);

-- Pool entries + resolution scan.
create index predictions_pool_idx
  on public.predictions (pool_id);

-- "My picks".
create index predictions_user_created_idx
  on public.predictions (user_id, created_at desc);

-- My splits.
create index splits_creator_created_idx
  on public.splits (creator_id, created_at desc);

-- Legs per split.
create index split_members_split_idx
  on public.split_members (split_id);

-- Partial: "you owe" badge.
create index split_members_owed_idx
  on public.split_members (user_id)
  where status = 'REQUESTED';

-- Case-insensitive friend search.
create index users_username_lower_idx
  on public.users (lower(username));
