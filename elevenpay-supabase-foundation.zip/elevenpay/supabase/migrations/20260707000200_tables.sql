-- ============================================================================
-- 0200: Tables (10) — per docs/database-design.md (source of truth per DATABASE.md)
--
-- Rules applied everywhere:
--   * Money columns are numeric(20,6), never float.
--   * Timestamps are timestamptz, never naive.
--   * Status/type columns are text with CHECK constraints.
--   * Every table: uuid PK (gen_random_uuid()), created_at default now().
--   * No key material of any kind is stored — addresses and metadata only.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. users — profile row, 1:1 with auth.users
-- ----------------------------------------------------------------------------
create table public.users (
  id uuid primary key references auth.users (id) on delete cascade,
  username text unique,
  full_name text not null default '',
  email text,
  avatar_url text,
  favorite_team text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint users_username_format check (
    username is null or username ~ '^[a-z0-9_]{3,20}$'
  ),
  constraint users_full_name_length check (char_length(full_name) <= 80)
);

comment on table public.users is
  'Profile row linked 1:1 with auth.users. Created by trigger on auth signup.';

-- ----------------------------------------------------------------------------
-- 2. wallets — public address registry + display balance cache (NOT custody)
-- ----------------------------------------------------------------------------
create table public.wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users (id) on delete cascade,
  wallet_address text unique not null,
  blockchain text not null default 'ethereum-sepolia',
  balance numeric(20, 6) not null default 0,
  balance_updated_at timestamptz,
  created_at timestamptz not null default now(),
  constraint wallets_one_per_chain unique (user_id, blockchain),
  constraint wallets_blockchain_supported check (
    blockchain in ('ethereum-sepolia', 'ethereum', 'polygon', 'arbitrum')
  ),
  constraint wallets_balance_non_negative check (balance >= 0)
);

comment on column public.wallets.balance is
  'Display cache only — the chain is the source of truth for funds.';

-- ----------------------------------------------------------------------------
-- 3. transactions — append-only payment ledger
-- ----------------------------------------------------------------------------
create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  sender_wallet uuid references public.wallets (id) on delete restrict,
  receiver_wallet uuid references public.wallets (id) on delete restrict,
  amount numeric(20, 6) not null,
  fee numeric(20, 6) not null default 0,
  currency text not null default 'USDT',
  transaction_hash text unique,
  type text not null,
  status text not null default 'PENDING',
  reference_id uuid,
  idempotency_key uuid unique,
  memo text,
  created_at timestamptz not null default now(),
  confirmed_at timestamptz,
  constraint transactions_amount_positive check (amount > 0),
  constraint transactions_fee_non_negative check (fee >= 0),
  constraint transactions_type_valid check (
    type in ('SEND', 'WATCH_PARTY', 'POOL_ENTRY', 'POOL_REWARD', 'SPLIT_BILL', 'TIP', 'FAUCET')
  ),
  constraint transactions_status_valid check (
    status in ('PENDING', 'BROADCAST', 'SUCCESS', 'FAILED')
  ),
  constraint transactions_memo_length check (memo is null or char_length(memo) <= 280),
  constraint transactions_endpoint_present check (
    sender_wallet is not null or receiver_wallet is not null
  ),
  constraint transactions_no_self_send check (
    sender_wallet is distinct from receiver_wallet
  )
);

comment on table public.transactions is
  'Append-only ledger. Clients insert PENDING intents; only service role marks SUCCESS/FAILED after on-chain verification. No UPDATE except status transitions, no DELETE ever.';
comment on column public.transactions.reference_id is
  'Polymorphic link interpreted by type: watch_parties.id, prediction_pools.id, or splits.id.';

-- ----------------------------------------------------------------------------
-- 4. matches — seeded/demo football match data
-- ----------------------------------------------------------------------------
create table public.matches (
  id uuid primary key default gen_random_uuid(),
  team_a text not null,
  team_b text not null,
  kickoff_at timestamptz not null,
  status text not null default 'SCHEDULED',
  winner_team text,
  created_at timestamptz not null default now(),
  constraint matches_status_valid check (status in ('SCHEDULED', 'LIVE', 'FINISHED')),
  constraint matches_winner_valid check (
    winner_team is null or winner_team in (team_a, team_b)
  )
);

-- ----------------------------------------------------------------------------
-- 5. watch_parties — public discovery + event metadata
-- ----------------------------------------------------------------------------
create table public.watch_parties (
  id uuid primary key default gen_random_uuid(),
  organizer_id uuid not null references public.users (id) on delete restrict,
  match_id uuid references public.matches (id) on delete set null,
  title text not null,
  venue text not null,
  city text not null,
  match_name text,
  entry_fee numeric(20, 6) not null default 0,
  max_participants integer not null,
  event_date timestamptz not null,
  image_url text,
  status text not null default 'OPEN',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint watch_parties_title_length check (char_length(title) between 3 and 80),
  constraint watch_parties_entry_fee_non_negative check (entry_fee >= 0),
  constraint watch_parties_capacity_positive check (
    max_participants > 0 and max_participants <= 500
  ),
  constraint watch_parties_status_valid check (
    status in ('OPEN', 'FULL', 'PAST', 'CANCELLED')
  )
);

-- ----------------------------------------------------------------------------
-- 6. watch_party_members — membership + seat reservation lifecycle
-- ----------------------------------------------------------------------------
create table public.watch_party_members (
  id uuid primary key default gen_random_uuid(),
  watch_party_id uuid not null references public.watch_parties (id) on delete cascade,
  user_id uuid not null references public.users (id) on delete cascade,
  payment_status text not null default 'RESERVED',
  reserved_until timestamptz,
  transaction_id uuid references public.transactions (id) on delete set null,
  joined_at timestamptz not null default now(),
  constraint watch_party_members_join_once unique (watch_party_id, user_id),
  constraint watch_party_members_status_valid check (
    payment_status in ('RESERVED', 'PAID', 'EXPIRED', 'CANCELLED')
  )
);

comment on column public.watch_party_members.reserved_until is
  'Seat hold deadline (3 minutes). Expiry via lazy sweep in join_party / expire_party_reservations.';

-- ----------------------------------------------------------------------------
-- 7. prediction_pools
-- ----------------------------------------------------------------------------
create table public.prediction_pools (
  id uuid primary key default gen_random_uuid(),
  match_id uuid references public.matches (id) on delete set null,
  watch_party_id uuid references public.watch_parties (id) on delete set null,
  match_name text not null,
  team_a text not null,
  team_b text not null,
  entry_fee numeric(20, 6) not null,
  prize_pool numeric(20, 6) not null default 0,
  status text not null default 'OPEN',
  winner_team text,
  closes_at timestamptz not null,
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint prediction_pools_entry_fee_positive check (entry_fee > 0),
  constraint prediction_pools_prize_non_negative check (prize_pool >= 0),
  constraint prediction_pools_status_valid check (
    status in ('OPEN', 'LIVE', 'FINISHED', 'CANCELLED')
  ),
  constraint prediction_pools_winner_valid check (
    winner_team is null or winner_team in (team_a, team_b)
  ),
  constraint prediction_pools_finished_has_winner check (
    status <> 'FINISHED' or winner_team is not null
  )
);

comment on column public.prediction_pools.prize_pool is
  'Denormalized for the feed (maintained by trigger); resolution recomputes from predictions before paying out.';

-- ----------------------------------------------------------------------------
-- 8. predictions — one final pick per user per pool
-- ----------------------------------------------------------------------------
create table public.predictions (
  id uuid primary key default gen_random_uuid(),
  pool_id uuid not null references public.prediction_pools (id) on delete cascade,
  user_id uuid not null references public.users (id) on delete cascade,
  selected_team text not null,
  is_winner boolean,
  transaction_id uuid references public.transactions (id) on delete set null,
  created_at timestamptz not null default now(),
  constraint predictions_one_pick unique (pool_id, user_id)
);

comment on column public.predictions.is_winner is
  'NULL until the pool is resolved; set only by service role.';

-- ----------------------------------------------------------------------------
-- 9. splits — bill split header
-- ----------------------------------------------------------------------------
create table public.splits (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.users (id) on delete cascade,
  total_amount numeric(20, 6) not null,
  currency text not null default 'USDT',
  memo text,
  status text not null default 'OPEN',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint splits_total_positive check (total_amount > 0),
  constraint splits_memo_length check (memo is null or char_length(memo) <= 140),
  constraint splits_status_valid check (status in ('OPEN', 'SETTLED', 'CANCELLED'))
);

-- ----------------------------------------------------------------------------
-- 10. split_members — each participant''s leg
-- ----------------------------------------------------------------------------
create table public.split_members (
  id uuid primary key default gen_random_uuid(),
  split_id uuid not null references public.splits (id) on delete cascade,
  user_id uuid references public.users (id) on delete cascade,
  external_ref text,
  share_amount numeric(20, 6) not null,
  status text not null default 'REQUESTED',
  transaction_id uuid references public.transactions (id) on delete set null,
  reminded_at timestamptz,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  constraint split_members_share_positive check (share_amount > 0),
  constraint split_members_status_valid check (
    status in ('REQUESTED', 'PAID', 'CANCELLED')
  ),
  constraint split_members_identity_present check (
    user_id is not null or external_ref is not null
  ),
  constraint split_members_unique_user unique (split_id, user_id)
);

comment on column public.split_members.external_ref is
  'Share-link token for non-user friends paying via link.';
