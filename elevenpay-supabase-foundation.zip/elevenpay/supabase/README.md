# ElevenPay Supabase Backend

Database foundation for ElevenPay: 10 tables, indexes, triggers, views,
default-deny RLS, and atomic RPCs. Design source of truth:
`docs/database-design.md` (see also `DATABASE.md`).

## Layout

```
supabase/
├── config.toml                # Local dev config (API 54321, DB 54322, Studio 54323)
├── seed.sql                   # Demo data — local development only
└── migrations/
    ├── 20260707000100_extensions_and_helpers.sql
    ├── 20260707000200_tables.sql
    ├── 20260707000300_indexes.sql
    ├── 20260707000400_triggers.sql
    ├── 20260707000500_views.sql
    ├── 20260707000600_rls.sql
    └── 20260707000700_functions.sql
```

## Run locally

```bash
npx supabase start        # boots Postgres + API + Studio (Docker required)
npx supabase db reset     # applies all migrations, then seed.sql
```

Then point the app's `.env`:

```
EXPO_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321
EXPO_PUBLIC_SUPABASE_ANON_KEY=<anon key printed by `supabase start`>
```

Demo accounts (local seed only): `ansh@elevenpay.demo`, `alex@elevenpay.demo`,
`john@elevenpay.demo`, `emma@elevenpay.demo` — password `Password123!`.

## Deploy to a hosted project

```bash
npx supabase link --project-ref <project-ref>
npx supabase db push      # applies migrations (never run seed.sql in prod)
```

## Regenerate types

```bash
npx supabase gen types typescript --local > src/types/database.ts
```

## Security model (summary)

- **Default deny**: RLS enabled on all 10 tables; `anon` has no table access.
- **Clients claim intent, the server claims success**: clients may insert
  `PENDING` transactions from their own wallet only; `SUCCESS`/`FAILED` flips,
  `PAID` seat/leg flips, `is_winner`, and `POOL_REWARD`/`FAUCET` minting are
  service-role only (policies + guard triggers).
- **Ledger is append-only**: no deletes; only legal status transitions.
- **Privacy via views**: `public_profiles` (no email), `party_attendance`
  (counts, not payment status), `party_attendee_previews`.
- **Atomic money ops via RPCs**: `join_party`, `enter_pool`, `create_split`,
  `pay_split_leg`, `resolve_pool` (service-role), `demo_faucet`,
  `resolve_wallet`, `expire_party_reservations`.
- **No key material** anywhere in this schema — addresses and metadata only.
