/**
 * Transaction repository — the append-only payment ledger.
 *
 * Clients may ONLY insert PENDING intents from their own wallet (enforced by
 * RLS + triggers). Status flips to BROADCAST/SUCCESS/FAILED happen server-side
 * (edge function with service role) after on-chain verification. Never trust
 * the client about money.
 */

import { supabase } from '@/services/supabase/client';
import type { Tables, TransactionType } from '@/types/database';
import { toAmountString } from './types';

export type Transaction = Omit<Tables<'transactions'>, 'amount' | 'fee'> & {
  amount: string;
  fee: string;
};

function toTransaction(row: Tables<'transactions'>): Transaction {
  return { ...row, amount: toAmountString(row.amount), fee: toAmountString(row.fee) };
}

export type CreatePendingInput = {
  sender_wallet: string;
  receiver_wallet: string | null;
  /** Decimal string, e.g. '5.000000'. */
  amount: string;
  type: Extract<TransactionType, 'SEND' | 'WATCH_PARTY' | 'POOL_ENTRY' | 'SPLIT_BILL' | 'TIP'>;
  reference_id?: string | null;
  memo?: string | null;
  /** Client-generated UUID; retries with the same key cannot double-pay. */
  idempotency_key: string;
};

/** Step 1 of the payment pipeline: record the PENDING intent. */
export async function createPendingTransaction(
  input: CreatePendingInput,
): Promise<Transaction> {
  const { data, error } = await supabase
    .from('transactions')
    .insert({
      sender_wallet: input.sender_wallet,
      receiver_wallet: input.receiver_wallet,
      amount: Number(input.amount),
      type: input.type,
      status: 'PENDING',
      reference_id: input.reference_id ?? null,
      memo: input.memo ?? null,
      idempotency_key: input.idempotency_key,
    })
    .select()
    .single();
  if (error) throw error;
  return toTransaction(data);
}

/** History for the signed-in user (RLS scopes to own wallets), newest first. */
export async function listMyTransactions(options?: {
  limit?: number;
  before?: string;
}): Promise<Transaction[]> {
  let query = supabase
    .from('transactions')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(options?.limit ?? 25);

  if (options?.before) {
    query = query.lt('created_at', options.before);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []).map(toTransaction);
}

export async function getTransaction(id: string): Promise<Transaction | null> {
  const { data, error } = await supabase
    .from('transactions')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data ? toTransaction(data) : null;
}

/** Payments linked to a party/pool/split (visibility still RLS-scoped). */
export async function listTransactionsByReference(
  referenceId: string,
): Promise<Transaction[]> {
  const { data, error } = await supabase
    .from('transactions')
    .select('*')
    .eq('reference_id', referenceId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []).map(toTransaction);
}
