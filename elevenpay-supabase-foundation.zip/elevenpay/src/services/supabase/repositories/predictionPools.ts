/**
 * Prediction pool repository — pools feed, entries, and results.
 *
 * enter_pool is an atomic RPC: validates the pool is OPEN (server clock),
 * enforces one final pick per user, accrues the prize pool, and returns a
 * payment template for the standard pipeline. Other users' picks become
 * visible only after the pool closes (RLS-enforced, not UI-enforced).
 */

import { supabase } from '@/services/supabase/client';
import type { Tables } from '@/types/database';
import { toAmountString } from './types';
import type { EnterPoolResult } from './types';

export type PredictionPool = Omit<Tables<'prediction_pools'>, 'entry_fee' | 'prize_pool'> & {
  entry_fee: string;
  prize_pool: string;
};
export type Prediction = Tables<'predictions'>;

function toPool(row: Tables<'prediction_pools'>): PredictionPool {
  return {
    ...row,
    entry_fee: toAmountString(row.entry_fee),
    prize_pool: toAmountString(row.prize_pool),
  };
}

export async function listOpenPools(limit = 25): Promise<PredictionPool[]> {
  const { data, error } = await supabase
    .from('prediction_pools')
    .select('*')
    .eq('status', 'OPEN')
    .gt('closes_at', new Date().toISOString())
    .order('closes_at', { ascending: true })
    .limit(limit);
  if (error) throw error;
  return (data ?? []).map(toPool);
}

export async function getPool(id: string): Promise<PredictionPool | null> {
  const { data, error } = await supabase
    .from('prediction_pools')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data ? toPool(data) : null;
}

/** Atomic entry: one final pick + payment template. */
export async function enterPool(
  poolId: string,
  selectedTeam: string,
): Promise<EnterPoolResult> {
  const { data, error } = await supabase.rpc('enter_pool', {
    p_pool_id: poolId,
    p_selected_team: selectedTeam,
  });
  if (error) throw error;
  return data as EnterPoolResult;
}

export async function getMyPrediction(poolId: string): Promise<Prediction | null> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('UNAUTHENTICATED');

  const { data, error } = await supabase
    .from('predictions')
    .select('*')
    .eq('pool_id', poolId)
    .eq('user_id', auth.user.id)
    .maybeSingle();
  if (error) throw error;
  return data;
}

/**
 * All picks for a pool. RLS returns only the caller's own row while the pool
 * is OPEN; everyone's picks after it closes.
 */
export async function listPoolPredictions(poolId: string): Promise<Prediction[]> {
  const { data, error } = await supabase
    .from('predictions')
    .select('*')
    .eq('pool_id', poolId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data ?? [];
}

/** The caller's pick history ("my predictions" screen). */
export async function listMyPredictions(limit = 25): Promise<Prediction[]> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('UNAUTHENTICATED');

  const { data, error } = await supabase
    .from('predictions')
    .select('*')
    .eq('user_id', auth.user.id)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data ?? [];
}
