/**
 * Data-access layer for the ElevenPay Supabase backend.
 *
 * Feature code (src/features/**) should import from here rather than calling
 * the Supabase client directly. Repositories own the numeric -> decimal-string
 * conversion for money and wrap the money-moving RPCs (join_party, enter_pool,
 * create_split, pay_split_leg) that return payment templates.
 */

export * from './types';
export * as profiles from './profiles';
export * as wallets from './wallets';
export * as transactions from './transactions';
export * as matches from './matches';
export * as watchParties from './watchParties';
export * as predictionPools from './predictionPools';
export * as splits from './splits';
