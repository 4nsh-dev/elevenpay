/**
 * Match repository — read-only demo/seeded match data.
 * Writes are service-role only (seed scripts / resolve_pool).
 */

import { supabase } from '@/services/supabase/client';
import type { Tables } from '@/types/database';

export type Match = Tables<'matches'>;

export async function listMatches(options?: {
  status?: Match['status'];
  limit?: number;
}): Promise<Match[]> {
  let query = supabase
    .from('matches')
    .select('*')
    .order('kickoff_at', { ascending: true })
    .limit(options?.limit ?? 50);

  if (options?.status) {
    query = query.eq('status', options.status);
  }

  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function getMatch(id: string): Promise<Match | null> {
  const { data, error } = await supabase
    .from('matches')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data;
}
