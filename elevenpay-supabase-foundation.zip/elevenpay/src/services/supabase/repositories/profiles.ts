/**
 * Profile repository — own profile (users, RLS: own row) and public
 * discovery (public_profiles view; email is never exposed).
 */

import { supabase } from '@/services/supabase/client';
import type { Tables, TablesUpdate, Views } from '@/types/database';

export type Profile = Tables<'users'>;
export type PublicProfile = Views<'public_profiles'>;

export async function getMyProfile(): Promise<Profile | null> {
  const { data, error } = await supabase.from('users').select('*').maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateMyProfile(
  updates: Pick<TablesUpdate<'users'>, 'username' | 'full_name' | 'avatar_url' | 'favorite_team'>,
): Promise<Profile> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('UNAUTHENTICATED');

  const { data, error } = await supabase
    .from('users')
    .update(updates)
    .eq('id', auth.user.id)
    .select()
    .single();
  if (error) throw error;
  return data;
}

/** Prefix search for friends by username (max 10, safe columns only). */
export async function searchProfiles(usernamePrefix: string): Promise<PublicProfile[]> {
  const query = usernamePrefix.trim().toLowerCase();
  if (query.length < 2) return [];

  const { data, error } = await supabase
    .from('public_profiles')
    .select('*')
    .ilike('username', `${query}%`)
    .limit(10);
  if (error) throw error;
  return data ?? [];
}
