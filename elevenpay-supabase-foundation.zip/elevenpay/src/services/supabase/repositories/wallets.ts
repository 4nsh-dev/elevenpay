/**
 * Wallet repository — public address registry and display balance cache.
 *
 * Custody stays in src/services/wdk. This module never sees mnemonics,
 * keys, or signatures; it records addresses and cached balances only.
 */

import { supabase } from '@/services/supabase/client';
import type { Tables } from '@/types/database';
import { toAmountString } from './types';
import type { FaucetResult } from './types';

export type Wallet = Omit<Tables<'wallets'>, 'balance'> & { balance: string };

function toWallet(row: Tables<'wallets'>): Wallet {
  return { ...row, balance: toAmountString(row.balance) };
}

/** Registers the device-created wallet (called once after WDK keygen). */
export async function registerWallet(input: {
  wallet_address: string;
  blockchain?: string;
}): Promise<Wallet> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('UNAUTHENTICATED');

  const { data, error } = await supabase
    .from('wallets')
    .insert({ user_id: auth.user.id, ...input })
    .select()
    .single();
  if (error) throw error;
  return toWallet(data);
}

export async function getMyWallet(): Promise<Wallet | null> {
  const { data, error } = await supabase.from('wallets').select('*').maybeSingle();
  if (error) throw error;
  return data ? toWallet(data) : null;
}

/**
 * Reports the fresh chain balance the device just read via WDK.
 * Display cache only — the chain remains the source of truth.
 */
export async function syncBalance(walletId: string, balance: string): Promise<Wallet> {
  const { data, error } = await supabase
    .from('wallets')
    .update({ balance: Number(balance), balance_updated_at: new Date().toISOString() })
    .eq('id', walletId)
    .select()
    .single();
  if (error) throw error;
  return toWallet(data);
}

/** Resolves a username to a wallet address without exposing wallet rows. */
export async function resolveRecipient(username: string): Promise<{
  user_id: string;
  username: string | null;
  wallet_address: string;
  blockchain: string;
} | null> {
  const { data, error } = await supabase.rpc('resolve_wallet', { p_username: username });
  if (error) throw error;
  return data?.[0] ?? null;
}

/** Demo funding path — once per 24h per user. */
export async function requestDemoFaucet(): Promise<FaucetResult> {
  const { data, error } = await supabase.rpc('demo_faucet');
  if (error) throw error;
  return data as FaucetResult;
}
