/**
 * Shared repository types.
 *
 * Every money-moving RPC returns a PAYMENT TEMPLATE. The client always runs
 * the same pipeline with it: create PENDING transaction -> confirm sheet ->
 * WDK sign -> submit hash. Repositories never sign or broadcast anything.
 *
 * Amounts travel as decimal strings ("5.000000") in app code — numeric
 * columns arrive as JSON numbers from PostgREST and are converted at this
 * boundary via toAmountString.
 */

import type { TransactionType } from '@/types/database';

export type PaymentTemplate = {
  amount: string;
  receiver_wallet: string;
  type: Extract<TransactionType, 'SEND' | 'WATCH_PARTY' | 'POOL_ENTRY' | 'SPLIT_BILL' | 'TIP'>;
  reference_id: string | null;
};

export type JoinPartyResult = {
  membership_id: string;
  payment_status: 'RESERVED' | 'PAID';
  reserved_until: string | null;
  payment: PaymentTemplate | null;
};

export type EnterPoolResult = {
  prediction_id: string;
  payment: PaymentTemplate;
};

export type PaySplitLegResult = {
  leg_id: string;
  payment: PaymentTemplate;
};

export type CreateSplitMemberInput =
  | { self: true; share_amount: string }
  | { user_id: string; share_amount: string }
  | { external_ref?: string; share_amount: string };

export type CreateSplitResult = {
  split_id: string;
  status: 'OPEN';
  total_amount: string;
  memo: string | null;
  legs: Array<{
    leg_id: string;
    user_id: string | null;
    external_ref: string | null;
    share_amount: string;
    status: 'REQUESTED' | 'PAID';
  }>;
  share_links: Array<{ leg_id: string; external_ref: string }>;
};

export type FaucetResult = {
  transaction_id: string;
  amount: string;
  status: 'SUCCESS';
};

/**
 * Converts a PostgREST numeric value to the canonical 6-decimal string form.
 * Never do arithmetic on the number form of money in app code.
 */
export function toAmountString(value: number | string): string {
  const numeric = typeof value === 'string' ? Number(value) : value;
  if (!Number.isFinite(numeric)) {
    throw new Error(`Invalid money value: ${value}`);
  }
  return numeric.toFixed(6);
}
