/**
 * Watch party repository — discovery, membership, and the join flow.
 *
 * join_party is an atomic RPC: capacity check + 3-minute seat hold in one
 * transaction. Paid joins return a payment template for the standard
 * pipeline; the seat flips to PAID server-side after verification.
 */

import { supabase } from '@/services/supabase/client';
import type { Tables, TablesInsert, Views } from '@/types/database';
import { toAmountString } from './types';
import type { JoinPartyResult } from './types';

export type WatchParty = Omit<Tables<'watch_parties'>, 'entry_fee'> & { entry_fee: string };
export type WatchPartyMember = Tables<'watch_party_members'>;
export type PartyAttendance = Views<'party_attendance'>;
export type PartyAttendeePreview = Views<'party_attendee_previews'>;

function toWatchParty(row: Tables<'watch_parties'>): WatchParty {
  return { ...row, entry_fee: toAmountString(row.entry_fee) };
}

export async function listUpcomingParties(options?: {
  city?: string;
  limit?: number;
}): Promise<WatchParty[]> {
  let query = supabase
    .from('watch_parties')
    .select('*')
    .eq('status', 'OPEN')
    .gte('event_date', new Date().toISOString())
    .order('event_date', { ascending: true })
    .limit(options?.limit ?? 25);

  if (options?.city) {
    query = query.eq('city', options.city);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []).map(toWatchParty);
}

export async function getWatchParty(id: string): Promise<WatchParty | null> {
  const { data, error } = await supabase
    .from('watch_parties')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data ? toWatchParty(data) : null;
}

export async function createWatchParty(
  input: Omit<TablesInsert<'watch_parties'>, 'organizer_id' | 'entry_fee'> & {
    entry_fee?: string;
  },
): Promise<WatchParty> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('UNAUTHENTICATED');

  const { data, error } = await supabase
    .from('watch_parties')
    .insert({
      ...input,
      organizer_id: auth.user.id,
      entry_fee: input.entry_fee ? Number(input.entry_fee) : 0,
    })
    .select()
    .single();
  if (error) throw error;
  return toWatchParty(data);
}

/** Atomic join: seat reservation + payment template (null for free parties). */
export async function joinParty(partyId: string): Promise<JoinPartyResult> {
  const { data, error } = await supabase.rpc('join_party', { p_party_id: partyId });
  if (error) throw error;
  return data as JoinPartyResult;
}

/** Cancels the caller's own RESERVED seat (PAID seats cannot be cancelled here). */
export async function cancelMyReservation(partyId: string): Promise<void> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('UNAUTHENTICATED');

  const { error } = await supabase
    .from('watch_party_members')
    .update({ payment_status: 'CANCELLED' })
    .eq('watch_party_id', partyId)
    .eq('user_id', auth.user.id)
    .eq('payment_status', 'RESERVED');
  if (error) throw error;
}

export async function getMyMembership(partyId: string): Promise<WatchPartyMember | null> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) throw new Error('UNAUTHENTICATED');

  const { data, error } = await supabase
    .from('watch_party_members')
    .select('*')
    .eq('watch_party_id', partyId)
    .eq('user_id', auth.user.id)
    .maybeSingle();
  if (error) throw error;
  return data;
}

/** Seat counts without exposing member payment details. */
export async function getPartyAttendance(partyId: string): Promise<PartyAttendance | null> {
  const { data, error } = await supabase
    .from('party_attendance')
    .select('*')
    .eq('watch_party_id', partyId)
    .maybeSingle();
  if (error) throw error;
  return data;
}

/** "Who's going" avatar strip (public profile fields only). */
export async function listPartyAttendees(
  partyId: string,
  limit = 12,
): Promise<PartyAttendeePreview[]> {
  const { data, error } = await supabase
    .from('party_attendee_previews')
    .select('*')
    .eq('watch_party_id', partyId)
    .order('joined_at', { ascending: true })
    .limit(limit);
  if (error) throw error;
  return data ?? [];
}
