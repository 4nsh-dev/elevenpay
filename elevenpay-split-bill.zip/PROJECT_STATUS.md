# ElevenPay — Project Status

_Last updated: 8 July 2026 — split bills wired to Supabase (feature complete)._

## Snapshot

| Layer | Status |
| --- | --- |
| UI / design system / navigation | ✅ Built (untouched) |
| Authentication (Supabase Auth) | ✅ Built |
| Auth ↔ Supabase profiles wiring | ✅ Done |
| WDK wallet layer (custody, signing) | ✅ Built (untouched) |
| WDK ↔ Supabase wallet sync | ✅ Done |
| Persistent transaction storage | ✅ Done |
| Watch parties (live data, joins, participants, payments) | ✅ Done |
| Prediction pools (creation, entries, payments, results, payouts) | ✅ Done |
| **Split bills (create, AI shares, requests, WDK payments, history)** | ✅ **Done — this pass** |
| Database schema (10 tables, FKs, indexes) | ✅ Done |
| Row Level Security (default-deny) | ✅ Done |
| Triggers (guards, profile bootstrap, settlement) | ✅ Done |
| Views (privacy shaping) | ✅ Done |
| RPCs (atomic money operations) | ✅ Done (+ `confirm_split_payment`) |
| Database types (`src/types/database.ts`) | ✅ Done |
| Seed data | ✅ Done |
| Repository/data-access layer | ✅ Done |
| Edge functions (submit-tx SUCCESS confirmation, faucet) | ⏳ Next |
| Realtime subscriptions | ⏳ Next |
| Guest share-link claim flow | ⏳ Next |

## This pass: split bill end to end

The `/split` placeholder screen is now the full feature (write-up in
`docs/split-bill-supabase.md`):

- **Create bill** — total + memo + participants, stored atomically via the
  `create_split` RPC (1–20 members, shares must sum exactly; the creator's
  own leg settles instantly).
- **Add participants** — friend search over `public_profiles` usernames,
  plus guests without accounts (server-generated share codes).
- **AI calculates shares** — on-device assistant with exact micro-USDT
  math: honors locked shares, splits the remainder evenly, assigns rounding
  so totals always balance, and explains what it did. Contract is swappable
  for a hosted LLM later.
- **Generate payment requests** — every leg is a persistent `REQUESTED` row;
  members see requests addressed to them in the Activity tab with the
  creator's name and memo.
- **Complete WDK payments** — `pay_split_leg` returns the payment template,
  the standard confirm sheet signs with WDK and broadcasts through the
  persistent ledger pipeline, and the new `confirm_split_payment` RPC
  verifies the ledger row and flips the leg to PAID (split auto-settles when
  the last leg pays).
- **Save history** — splits, legs, receipts, and transfers all live in
  Supabase; the Activity tab shows both directions with paid-leg progress.
- **Professional UX** — segmented New split / Activity flow, debounced
  friend search, lock/auto share chips, live unassigned-amount indicator,
  AI explanation callout, loading/error/empty states, and a success view
  listing every request.

### Files changed in this pass

```
supabase/migrations/20260707001100_confirm_split_payment.sql  (new)
src/features/split-bill/split-service.ts                      (new)
src/features/split-bill/use-splits.ts                         (new)
src/features/split-bill/index.ts                              (rewritten — was a stub)
src/services/supabase/repositories/splits.ts                  (modified — confirm + batch helpers)
src/types/database.ts                                         (modified — RPC typing)
app/split.tsx                                                 (rewritten — was a placeholder)
app/confirm.tsx                                               (modified — split leg confirmation)
docs/split-bill-supabase.md                                   (new)
PROJECT_STATUS.md                                             (this file)
```

## Previous passes

- **Supabase foundation** — schema, RLS, triggers, views, RPCs, types, seed
  data, repositories (`supabase/README.md`).
- **Auth ↔ profiles** — automatic profile bootstrap after signup, profile
  fetch on login, session store wiring.
- **WDK ↔ wallet sync** — wallet registration + balance/metadata sync
  (`docs/wallet-supabase-sync.md`). Private keys never leave the device.
- **Persistent transaction storage** — idempotency-keyed ledger writes with
  an AsyncStorage outbox and retry (`supabase/README.md`).
- **Watch parties** — live parties, atomic joins, participants, capacity,
  payment-backed seats (`docs/watch-party-supabase.md`).
- **Prediction pools** — live pools, atomic entries, treasury-settled
  payouts with WDK proof (`docs/prediction-pools-supabase.md`).

## How to apply

Local: `npx supabase start && npx supabase db reset` (applies all migrations
+ seed). Hosted: `npx supabase link --project-ref <ref> && npx supabase db
push`.
