/**
 * Dummy watch-party data has been removed. Every watch party now comes from
 * Supabase: `watch_parties`, `watch_party_members`, the `party_attendance`
 * and `party_attendee_previews` views, and the atomic `join_party` RPC.
 *
 * See `watch-party-service.ts` for the live data layer and
 * `use-watch-parties.ts` for the screen hooks.
 *
 * This placeholder only exists because the delivery zip cannot delete files.
 * It is safe (and recommended) to delete this file from the repository.
 */
export {};
