import { useCallback, useEffect, useState } from 'react';

import {
  getPartyDetail,
  listParties,
  type WatchPartyDetail,
  type WatchPartyView,
} from './watch-party-service';

/** Fetch upcoming watch parties plus the ids the user already paid for. */
export function useWatchParties() {
  const [parties, setParties] = useState<WatchPartyView[]>([]);
  const [joinedPartyIds, setJoinedPartyIds] = useState<Set<string>>(new Set());
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    setError(null);
    try {
      const result = await listParties();
      setParties(result.parties);
      setJoinedPartyIds(new Set(result.joinedPartyIds));
    } catch (caught) {
      setError(
        caught instanceof Error ? caught.message : 'Could not load watch parties right now.',
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  return { parties, joinedPartyIds, isLoading, error, reload };
}

/** Fetch one watch party with attendance, attendees, host, and my membership. */
export function useWatchPartyDetail(id: string | undefined) {
  const [detail, setDetail] = useState<WatchPartyDetail | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    if (!id) {
      setNotFound(true);
      setIsLoading(false);
      return;
    }
    setError(null);
    try {
      const next = await getPartyDetail(id);
      setDetail(next);
      setNotFound(next === null);
    } catch (caught) {
      setError(
        caught instanceof Error ? caught.message : 'Could not load this watch party right now.',
      );
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void reload();
  }, [reload]);

  return { detail, isLoading, notFound, error, reload };
}
