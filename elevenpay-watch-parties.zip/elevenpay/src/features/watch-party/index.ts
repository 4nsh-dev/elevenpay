/**
 * Watch party feature: Supabase-backed discovery, seat reservation via the
 * atomic `join_party` RPC, and entry-fee payment through the shared confirm
 * sheet (WDK signing + persistent transaction ledger).
 */
export {
  beginJoinParty,
  confirmWatchPartySeat,
  formatPartyTime,
  friendlyJoinError,
  getPartyDetail,
  listParties,
  reservationLabel,
  type JoinOutcome,
  type WatchPartyDetail,
  type WatchPartyParticipant,
  type WatchPartyView,
} from './watch-party-service';
export { useWatchParties, useWatchPartyDetail } from './use-watch-parties';
