-- ----------------------------------------------------------------------------
-- 20260707000900_confirm_party_payment.sql
-- Links a broadcast entry-fee payment to the payer's watch party seat.
--
-- The confirm sheet records the WATCH_PARTY transfer in public.transactions
-- (PENDING -> BROADCAST with hash, migration 000800). This RPC verifies that
-- ledger row server-side and flips the caller's membership RESERVED -> PAID
-- with the receipt linked. It is security definer (the function owner passes
-- public.is_service_role()), so the watch_party_members guard's "PAID via
-- server" rule is preserved: clients still cannot flip PAID directly.
--
-- Hardening note: once the submit-tx edge function confirms on-chain SUCCESS,
-- tighten the status filter below from ('BROADCAST', 'SUCCESS') to 'SUCCESS'.
-- ----------------------------------------------------------------------------

create or replace function public.confirm_party_payment(p_party_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_party public.watch_parties%rowtype;
  v_membership public.watch_party_members%rowtype;
  v_seats integer;
  v_tx_id uuid;
begin
  if v_uid is null then
    raise exception 'UNAUTHENTICATED: sign in to confirm a party payment';
  end if;

  select * into v_party
  from public.watch_parties
  where id = p_party_id
  for update;

  if not found then
    raise exception 'NOT_FOUND: watch party does not exist';
  end if;

  select * into v_membership
  from public.watch_party_members
  where watch_party_id = p_party_id and user_id = v_uid
  for update;

  if not found then
    raise exception 'NOT_FOUND: no membership for this party';
  end if;

  if v_membership.payment_status = 'PAID' then
    return jsonb_build_object(
      'membership_id', v_membership.id,
      'payment_status', 'PAID',
      'transaction_id', v_membership.transaction_id
    );
  end if;

  if v_membership.payment_status = 'CANCELLED' then
    raise exception 'CONFLICT: membership was cancelled';
  end if;

  -- Verify the caller really broadcast an entry-fee payment for this party.
  select t.id into v_tx_id
  from public.transactions t
  where t.type = 'WATCH_PARTY'
    and t.reference_id = p_party_id
    and t.status in ('BROADCAST', 'SUCCESS')
    and t.sender_wallet in (
      select w.id from public.wallets w where w.user_id = v_uid
    )
  order by t.created_at desc
  limit 1;

  if v_tx_id is null then
    raise exception 'NOT_FOUND: no broadcast entry-fee transaction for this party';
  end if;

  -- An EXPIRED hold already freed its seat; re-check capacity before restoring.
  if v_membership.payment_status = 'EXPIRED' then
    select count(*) into v_seats
    from public.watch_party_members
    where watch_party_id = p_party_id
      and payment_status in ('RESERVED', 'PAID');
    if v_seats >= v_party.max_participants then
      raise exception 'PARTY_FULL: no seats left';
    end if;
  end if;

  update public.watch_party_members
  set payment_status = 'PAID',
      transaction_id = v_tx_id,
      reserved_until = null
  where id = v_membership.id
  returning * into v_membership;

  return jsonb_build_object(
    'membership_id', v_membership.id,
    'payment_status', v_membership.payment_status,
    'transaction_id', v_membership.transaction_id
  );
end;
$$;

revoke all on function public.confirm_party_payment(uuid) from public;
grant execute on function public.confirm_party_payment(uuid) to authenticated;
