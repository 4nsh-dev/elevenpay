# Watch Parties on Supabase

How the watch-party feature works after the live-data pass (all dummy data
removed).

## Data sources

| UI need | Source |
| --- | --- |
| Upcoming parties | `watch_parties` via `repositories/watchParties.listUpcomingParties()` |
| Live seat counts | `party_attendance` view (`seats_taken`, `seats_left`) |
| Participants list | `party_attendee_previews` view (privacy-shaped: name/username only) |
| Match line + Live badge | `matches` (`team_a` vs `team_b`, `status = 'LIVE'`) |
| Host name | `public_profiles` (organizer row) |
| Host wallet address | `resolve_wallet` RPC (via `repositories/wallets.resolveRecipient`) |
| My memberships | `watch_party_members` (own rows under RLS) |

The service (`src/features/watch-party/watch-party-service.ts`) shapes these
into a `WatchPartyView` whose fields match the old dummy model, so both
screens kept their exact layout. Hooks with loading/error state live in
`use-watch-parties.ts`.

## Join flow

1. **Join event** -> `join_party` RPC (atomic, server-side):
   - capacity check (`PARTY_FULL`), duplicate check (`ALREADY_EXISTS`,
     backed by `unique (watch_party_id, user_id)`), party-open check
     (`CONFLICT`), auth check (`UNAUTHENTICATED`).
   - Free party -> membership `PAID` immediately; the screen just reloads.
   - Paid party -> membership `RESERVED` with a 3-minute hold plus a payment
     template (amount, receiver wallet).
2. **Payment** -> the shared confirm sheet prepares/signs with WDK and
   records the transfer through the persistent ledger
   (`recordAndBroadcast`: PENDING row saved before signing, flipped to
   BROADCAST with the transaction hash, retry outbox on connectivity
   failures). No private keys ever leave WDK.
3. **Seat confirmation** -> `confirm_party_payment` RPC (migration 000900)
   verifies server-side that the caller owns a BROADCAST/SUCCESS
   `WATCH_PARTY` transaction referencing the party, then flips the
   membership to `PAID` and links `transaction_id` as the receipt. Direct
   client `PAID` flips remain blocked by the guard trigger.
4. Returning to the detail screen reloads live data: ticket banner, PAID
   chip, and updated seat counts.

An active `RESERVED` hold is resumed (button reads "Complete payment")
without re-calling `join_party`. Expired holds re-run the full
capacity-checked join. If the organizer has no linked wallet, the payment
draft cannot be built and the user sees a clear message instead.

## Error and edge handling

- RPC errors map to friendly copy (`friendlyJoinError`): full party,
  duplicate seat, closed party, signed out, vanished party.
- The list screen has loading, error, and empty states; the detail screen
  has loading, not-found, and error-with-retry states.
- Attendee previews intentionally hide RESERVED vs PAID; everyone shown
  holds a seat and is rendered with a PAID chip. The viewer is filtered out
  of the preview list to avoid duplicating the "You" row.
- `watch-party-data.ts` is now an empty placeholder (zip deliveries cannot
  delete files) - it is safe to delete from the repository.
- Prediction pools on the Watch tab still use dummy data (separate pass).

## Hardening next

- `confirm_party_payment` accepts `BROADCAST` today because on-chain
  SUCCESS confirmation (submit-tx edge function) is not built yet; tighten
  the filter to `SUCCESS` once that lands.
- Realtime subscriptions for live seat counts are a future pass.
