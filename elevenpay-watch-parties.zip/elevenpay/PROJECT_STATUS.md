# ElevenPay — Project Status

_Last updated: 8 July 2026 — watch parties wired to Supabase (dummy data removed)._

## Snapshot

| Layer | Status |
| --- | --- |
| UI / design system / navigation | ✅ Built (untouched) |
| Authentication (Supabase Auth) | ✅ Built |
| Auth ↔ Supabase profiles wiring | ✅ Done |
| WDK wallet layer (custody, signing) | ✅ Built (untouched) |
| WDK ↔ Supabase wallet sync | ✅ Done |
| Persistent transaction storage | ✅ Done |
| **Watch parties (live data, joins, participants, payments)** | ✅ **Done — this pass** |
| Database schema (10 tables, FKs, indexes) | ✅ Done |
| Row Level Security (default-deny) | ✅ Done |
| Triggers (guards, profile bootstrap, settlement) | ✅ Done |
| Views (privacy shaping) | ✅ Done |
| RPCs (atomic money operations) | ✅ Done (+ `confirm_party_payment`) |
| Database types (`src/types/database.ts`) | ✅ Done |
| Seed data | ✅ Done |
| Repository/data-access layer | ✅ Done |
| Prediction pools & splits wired to live data | ⏳ Next |
| Edge functions (submit-tx SUCCESS confirmation, resolve-pool, faucet) | ⏳ Next |
| Realtime subscriptions | ⏳ Next |

## This pass: watch parties on live data

Every dummy watch party is gone. The Watch tab, party detail, and join flow
now run on Supabase (full write-up in `docs/watch-party-supabase.md`):

- **Fetch from Supabase** — `watch-party-service.ts` hydrates a UI view
  model from `watch_parties`, the `party_attendance` view (live seat
  counts), the `party_attendee_previews` view, `matches`, and
  `public_profiles` (host identity + wallet via the `resolve_wallet` RPC).
- **Join watch party** — the `join_party` RPC reserves a seat atomically
  (3-minute hold). Free parties confirm instantly; paid parties hand a
  payment draft to the existing confirm sheet (WDK prepare → sign →
  broadcast, unchanged).
- **Store participants** — memberships live in `watch_party_members`
  (RESERVED/PAID/EXPIRED/CANCELLED); the participants list renders real
  attendees from the privacy-shaped preview view.
- **Store payments** — the entry fee goes through the persistent ledger
  (`recordAndBroadcast`): a PENDING row is saved before signing and flipped
  to BROADCAST with the hash. The new `confirm_party_payment` RPC
  (migration 000900) verifies that ledger row server-side and flips the
  membership to PAID with the receipt (`transaction_id`) linked; clients
  still cannot forge PAID directly (guard unchanged).
- **Handle capacity** — enforced server-side by `join_party` (`PARTY_FULL`);
  the UI disables the join button at 0 seats and shows live `seats_left`.
- **Handle duplicate joins** — `unique (watch_party_id, user_id)` +
  `ALREADY_EXISTS` from the RPC; the screen also resumes an active RESERVED
  hold ("Complete payment") instead of double-reserving, and maps all RPC
  errors to friendly copy.
- **UI kept** — both screens keep their exact layout and components; only
  data wiring, loading/error/empty states, and truthful labels changed.
  Prediction pools on the Watch tab remain dummy (separate pass).

### Files changed in this pass

```
supabase/migrations/20260707000900_confirm_party_payment.sql  (new — verified RESERVED → PAID flip)
src/features/watch-party/watch-party-service.ts  (new — Supabase data layer + join flow)
src/features/watch-party/use-watch-parties.ts    (new — list/detail hooks, loading + error)
src/features/watch-party/watch-party-data.ts     (gutted — dummy data removed; safe to delete)
src/features/watch-party/index.ts                (rewritten — exports the live layer)
app/(tabs)/watch.tsx                             (modified — live parties, loading/error/empty)
app/party/[id].tsx                               (modified — live detail, join via RPC)
app/confirm.tsx                                  (modified — ledger pipeline + seat confirmation)
src/types/database.ts                            (modified — confirm_party_payment typing)
docs/watch-party-supabase.md                     (new — flow + security notes)
PROJECT_STATUS.md                                (updated)
```

Not modified: `src/services/wdk/**`, auth files, design system components,
prediction pool and split features.

## Previous passes

- **Persistent transaction storage** — durable ledger in
  `public.transactions`: idempotency-keyed PENDING → BROADCAST/FAILED
  recording (`recordAndBroadcast`), AsyncStorage retry outbox, and
  `useTransactionsStore` loading/error state. Migration `20260707000800`
  lets the sender record BROADCAST/FAILED on their own PENDING intents;
  SUCCESS stays service-role only.
- **WDK ↔ Supabase wallet sync** — wallet registration, balance cache, and
  metadata sync; no key material leaves the device. See
  `docs/wallet-supabase-sync.md`.
- **Auth ↔ profiles** — profile auto-created at signup by the
  `on_auth_user_created` trigger; fetched with retry on every auth event
  (loading + error state in the session store); wallet linked to profile.
- **Supabase backend foundation** — seven migrations (all 10 tables from
  `DATABASE.md`, FKs, 17 indexes, guard/bootstrap triggers, privacy views,
  default-deny RLS, atomic RPCs), seed data, `config.toml`, full
  `src/types/database.ts`, typed repository layer under
  `src/services/supabase/repositories/`. See `supabase/README.md`.

## How to apply

```bash
npx supabase start && npx supabase db reset   # local (applies new 000900 migration)
# or
npx supabase link --project-ref <ref> && npx supabase db push   # hosted
```
