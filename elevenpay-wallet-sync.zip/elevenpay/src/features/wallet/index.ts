export {
  createWalletForUser,
  hydrateWallet,
  refreshTransactionHistory,
  refreshWallet,
} from './wallet-service';
export {
  ensureWalletRegistered,
  syncBalanceToSupabase,
  syncWalletWithSupabase,
} from './wallet-sync';
export type { DeviceWallet, WalletSyncResult } from './wallet-sync';
export { SAMPLE_ACTIVITY, buildSampleHistory, toActivityItem } from './sample-data';
export {
  HISTORY_FILTERS,
  filterHistory,
  groupByDay,
  statusSteps,
  type HistoryFilter,
  type HistorySection,
} from './history';
