/**
 * WDK ↔ Supabase wallet sync.
 *
 * Mirrors the on-device WDK wallet into `public.wallets` — METADATA ONLY:
 * address, blockchain, and a cached display balance. Mnemonics, private
 * keys, and signatures never leave SecureStore (see src/services/wdk).
 *
 * Security model for the profile ↔ wallet association:
 * - The `wallets` INSERT policy requires `user_id = auth.uid()`, so a wallet
 *   row can only ever be attached to the signed-in user's own profile.
 * - `wallet_address` is globally UNIQUE — no two accounts can claim the same
 *   address.
 * - After registration, address/chain/owner are immutable (guard trigger);
 *   clients may only refresh the balance cache.
 *
 * Every function here is best-effort and idempotent: a sync failure logs a
 * warning and never breaks the existing wallet flow.
 */

import { supabase } from '@/services/supabase/client';
import { wallets } from '@/services/supabase/repositories';
import { useWalletStore } from '@/stores/wallet';

export type DeviceWallet = {
  address: string;
  blockchain: string;
};

export type WalletSyncResult =
  | { status: 'registered'; walletId: string }
  | { status: 'already-registered'; walletId: string }
  | { status: 'address-mismatch'; registeredAddress: string }
  | { status: 'skipped'; reason: 'unauthenticated' };

const ADDRESS_MISMATCH_MESSAGE =
  'This device wallet does not match the wallet linked to your account. Restore the original recovery phrase or contact support.';

async function isSignedIn(): Promise<boolean> {
  const { data } = await supabase.auth.getSession();
  return Boolean(data.session?.user);
}

function sameAddress(a: string, b: string): boolean {
  return a.trim().toLowerCase() === b.trim().toLowerCase();
}

/**
 * Registers the device wallet in Supabase if it is not registered yet.
 * Idempotent; tolerant of the unique-violation race when two sessions
 * register concurrently.
 */
export async function ensureWalletRegistered(device: DeviceWallet): Promise<WalletSyncResult> {
  if (!(await isSignedIn())) return { status: 'skipped', reason: 'unauthenticated' };

  const existing = await wallets.getMyWallet();
  if (existing) {
    if (!sameAddress(existing.wallet_address, device.address)) {
      return { status: 'address-mismatch', registeredAddress: existing.wallet_address };
    }
    return { status: 'already-registered', walletId: existing.id };
  }

  try {
    const created = await wallets.registerWallet({
      wallet_address: device.address,
      blockchain: device.blockchain,
    });
    return { status: 'registered', walletId: created.id };
  } catch (error) {
    // Unique violation: another session won the race — re-read and reconcile.
    if ((error as { code?: string } | null)?.code === '23505') {
      const row = await wallets.getMyWallet();
      if (row && sameAddress(row.wallet_address, device.address)) {
        return { status: 'already-registered', walletId: row.id };
      }
      return { status: 'address-mismatch', registeredAddress: row?.wallet_address ?? '' };
    }
    throw error;
  }
}

/**
 * Full metadata sync used by the wallet flow: register if needed and surface
 * an address mismatch (device wallet ≠ account wallet) as a wallet error.
 * Never throws.
 */
export async function syncWalletWithSupabase(device: DeviceWallet): Promise<void> {
  try {
    const result = await ensureWalletRegistered(device);
    if (result.status === 'address-mismatch') {
      useWalletStore.getState().setWalletError(ADDRESS_MISMATCH_MESSAGE);
    }
  } catch (error) {
    console.warn('[wallet] Supabase wallet sync deferred:', error);
  }
}

/**
 * Pushes the fresh chain balance (already read via WDK) into the Supabase
 * display cache (`wallets.balance` + `balance_updated_at`). The chain stays
 * the source of truth; this cache only powers server-side displays.
 * Never throws.
 */
export async function syncBalanceToSupabase(balance: string): Promise<void> {
  try {
    if (!(await isSignedIn())) return;

    const row = await wallets.getMyWallet();
    if (!row) return;

    await wallets.syncBalance(row.id, balance);
  } catch (error) {
    console.warn('[wallet] Supabase balance sync deferred:', error);
  }
}
