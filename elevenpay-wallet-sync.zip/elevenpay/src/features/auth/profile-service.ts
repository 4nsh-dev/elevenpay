/**
 * Profile sync for the auth flow.
 *
 * The Supabase `on_auth_user_created` trigger creates the `public.users`
 * profile row automatically at signup (never the client — see
 * supabase/migrations/20260707000400_triggers.sql). This module's job is to:
 *
 *  1. Fetch that profile after login/signup (with a short retry, since the
 *     session can arrive a beat before the row is readable).
 *  2. Link the profile to the on-device WDK wallet via the wallet feature's
 *     sync layer (metadata only — no key material, ever).
 *  3. Report loading and error state through the session store so screens
 *     can render it without any UI changes.
 */

import { syncWalletWithSupabase } from '@/features/wallet';
import { profiles } from '@/services/supabase/repositories';
import { wdkService } from '@/services/wdk';
import { useSessionStore } from '@/stores/session';
import type { Tables } from '@/types/database';

export type Profile = Tables<'users'>;

const PROFILE_FETCH_ATTEMPTS = 4;
const PROFILE_FETCH_DELAY_MS = 600;

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms));
}

function friendlyProfileError(error: unknown): string {
  const message = error instanceof Error ? error.message : '';
  const lower = message.toLowerCase();

  if (lower.includes('network') || lower.includes('failed to fetch')) {
    return 'Network error. Check your connection and try again.';
  }
  if (lower.includes('jwt') || lower.includes('token')) {
    return 'Your session expired. Please sign in again.';
  }
  return 'Could not load your profile. Please try again.';
}

/**
 * Fetches the signed-in user's profile, retrying briefly to absorb the gap
 * between the auth session arriving and the trigger-created row being
 * readable on a fresh signup.
 */
export async function fetchProfileWithRetry(): Promise<Profile | null> {
  let lastError: unknown = null;

  for (let attempt = 1; attempt <= PROFILE_FETCH_ATTEMPTS; attempt += 1) {
    try {
      const profile = await profiles.getMyProfile();
      if (profile) return profile;
    } catch (error) {
      lastError = error;
    }
    if (attempt < PROFILE_FETCH_ATTEMPTS) {
      await sleep(PROFILE_FETCH_DELAY_MS * attempt);
    }
  }

  if (lastError) throw lastError;
  return null;
}

/**
 * Links the profile to the on-device wallet. Delegates to the wallet
 * feature's single sync path (`syncWalletWithSupabase`), which is idempotent
 * and RLS-scoped to the signed-in user. Best-effort — a failure here must
 * never block sign-in (the next auth event retries it).
 */
export async function linkWalletToProfile(userId: string): Promise<void> {
  try {
    if (!(await wdkService.hasWallet(userId))) return;

    const address = await wdkService.getAddress(userId);
    await syncWalletWithSupabase({ address, blockchain: 'ethereum-sepolia' });
  } catch (error) {
    console.warn('[auth] Wallet link deferred:', error);
  }
}

/**
 * Full post-auth sync: fetch profile (loading + error state in the session
 * store), then link the wallet. Called by AuthBootstrap on every auth state
 * change; safe to call repeatedly.
 */
export async function syncProfileAndWallet(userId: string): Promise<void> {
  const store = useSessionStore.getState();
  store.setProfileLoading();

  try {
    const profile = await fetchProfileWithRetry();

    // Session changed while we were fetching — drop the stale result.
    if (useSessionStore.getState().userId !== userId) return;

    if (!profile) {
      store.setProfileError('Your profile is still being set up. Please try again in a moment.');
      return;
    }

    store.setProfile(profile);
  } catch (error) {
    if (useSessionStore.getState().userId !== userId) return;
    store.setProfileError(friendlyProfileError(error));
    return;
  }

  await linkWalletToProfile(userId);
}

/** Re-fetches the profile on demand (e.g. after editing username/avatar). */
export async function refreshProfile(): Promise<void> {
  const { userId } = useSessionStore.getState();
  if (!userId) return;
  await syncProfileAndWallet(userId);
}
