# WDK ↔ Supabase Wallet Sync

How the on-device WDK wallet is connected to the Supabase backend.

## What syncs (and what never does)

| Data | Synced to Supabase? | Where |
| --- | --- | --- |
| Wallet address | ✅ Yes | `wallets.wallet_address` |
| Blockchain (`ethereum-sepolia`) | ✅ Yes | `wallets.blockchain` |
| Display balance + freshness | ✅ Yes (cache only) | `wallets.balance`, `wallets.balance_updated_at` |
| Mnemonic / seed phrase | ❌ **Never** | SecureStore only (`requireAuthentication`) |
| Private keys / signatures | ❌ **Never** | Derived on-device by WDK at signing time |
| Local transaction log | ❌ Not by this layer | Ledger rows come from the payment pipeline |

The chain remains the source of truth for balances — the Supabase value is a
display cache that powers server-side surfaces.

## Where it lives

- `src/features/wallet/wallet-sync.ts` — the sync layer:
  - `ensureWalletRegistered(device)` — registers the device wallet once;
    idempotent; reconciles the concurrent-registration race (unique
    violation); detects address mismatches.
  - `syncWalletWithSupabase(device)` — register + surface mismatch as a
    wallet error. Never throws.
  - `syncBalanceToSupabase(balance)` — pushes the WDK-read chain balance
    into the cache. Never throws.
- `src/features/wallet/wallet-service.ts` — existing flow, unchanged
  behavior; now fire-and-forgets the sync calls:
  - `hydrateWallet` → metadata sync after address load, balance sync after
    balance load.
  - `createWalletForUser` → registers the new wallet, then balance sync.
- `src/features/auth/profile-service.ts` — `linkWalletToProfile` delegates
  to `syncWalletWithSupabase` (single code path for registration).

## Secure profile ↔ wallet association

- **RLS**: the `wallets` INSERT policy requires `user_id = auth.uid()` — a
  wallet row can only attach to the signed-in user's own profile; the
  repository never passes a foreign user id.
- **Uniqueness**: `wallet_address` is globally UNIQUE — two accounts cannot
  claim the same address.
- **Immutability**: after registration, `user_id`, `wallet_address`, and
  `blockchain` are frozen by the `wallets_guard` trigger; clients may only
  refresh `balance`/`balance_updated_at`. Re-linking a different address is a
  service-role operation by design.
- **Mismatch handling**: if the device wallet differs from the registered one
  (e.g. a different recovery phrase was restored), sync sets a wallet error
  telling the user to restore the original phrase — it never overwrites the
  registered address.

## Failure semantics

All sync calls are best-effort and non-blocking: they run as fire-and-forget
promises after local state is set, log a warning on failure, and retry
naturally on the next hydrate/auth event. Wallet UX (create, restore,
balance, history) behaves identically with or without connectivity to
Supabase.

## When sync runs

1. App start / sign-in → `AuthBootstrap` → `hydrateWallet` + `linkWalletToProfile`.
2. Wallet creation → `createWalletForUser`.
3. Manual refresh → `refreshWallet` (delegates to `hydrateWallet`).
