# ElevenPay — Project Status

_Last updated: 7 July 2026 — WDK wallets connected to Supabase._

## Snapshot

| Layer | Status |
| --- | --- |
| UI / design system / navigation | ✅ Built (untouched) |
| Authentication (Supabase Auth) | ✅ Built |
| Auth ↔ Supabase profiles wiring | ✅ Done |
| WDK wallet layer (custody, signing) | ✅ Built (untouched) |
| **WDK ↔ Supabase wallet sync** | ✅ **Done — this pass** |
| Database schema (10 tables, FKs, indexes) | ✅ Done |
| Row Level Security (default-deny) | ✅ Done |
| Triggers (guards, profile bootstrap, settlement) | ✅ Done |
| Views (privacy shaping) | ✅ Done |
| RPCs (atomic money operations) | ✅ Done |
| Database types (`src/types/database.ts`) | ✅ Done |
| Seed data | ✅ Done |
| Repository/data-access layer | ✅ Done |
| Edge functions (submit-tx, resolve-pool, faucet) | ⏳ Next |
| Wiring features to repositories (replace mock data) | ⏳ Next |
| Realtime subscriptions | ⏳ Next |

## This pass: WDK wallets → Supabase

Full design: `docs/wallet-supabase-sync.md`.

- **Wallet registration** — new sync layer (`src/features/wallet/wallet-sync.ts`)
  registers the device wallet address in `public.wallets` on wallet creation
  and on every hydrate (idempotent, race-tolerant via the UNIQUE address
  constraint).
- **Balance sync** — after WDK reads the chain balance, it is pushed to the
  `wallets.balance` display cache with `balance_updated_at`; the chain stays
  the source of truth.
- **Metadata sync** — address + blockchain recorded at registration; frozen
  afterwards by the `wallets_guard` trigger (balance columns only remain
  client-updatable).
- **No private keys uploaded** — only address, chain, and cached balance
  cross the wire. Mnemonics/keys stay in SecureStore; signing stays inside
  `src/services/wdk` (unmodified).
- **Secure profile association** — RLS pins `wallets.user_id` to
  `auth.uid()`; addresses are globally unique; owner/address/chain are
  immutable post-registration; a device-vs-account address mismatch surfaces
  as a wallet error instead of overwriting.
- **Existing flow preserved** — `hydrateWallet` / `createWalletForUser` /
  `refreshWallet` keep their signatures and local behavior; sync calls are
  fire-and-forget and can never delay or fail the wallet UX. No UI files
  touched.

### Files changed in this pass

```
src/features/wallet/wallet-sync.ts        (new — register/balance/metadata sync)
src/features/wallet/wallet-service.ts     (modified — sync hooks in hydrate/create)
src/features/wallet/index.ts              (modified — exports for the sync layer)
src/features/auth/profile-service.ts      (modified — wallet link delegates to sync layer)
docs/wallet-supabase-sync.md              (new — sync design + security model)
PROJECT_STATUS.md                         (updated)
```

Not modified: `src/services/wdk/**` (WDK custody/signing), all UI components
and screens, auth screens/actions, stores.

## Previous passes

- **Auth ↔ profiles** — profile auto-created at signup by the
  `on_auth_user_created` trigger; `AuthBootstrap` fetches the profile with
  retry on every auth event (loading + error state in the session store) and
  links the device wallet. Additive `useProfile()` hook.
- **Supabase backend foundation** — seven migrations (all 10 tables from
  `DATABASE.md`, FKs, 17 indexes, guard/bootstrap triggers, privacy views,
  default-deny RLS, atomic RPCs), seed data, `config.toml`, full
  `src/types/database.ts`, typed repository layer under
  `src/services/supabase/repositories/`. See `supabase/README.md`.

## How to apply

```bash
npx supabase start && npx supabase db reset   # local
# or
npx supabase link --project-ref <ref> && npx supabase db push   # hosted
```
